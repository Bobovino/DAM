package pacientes.logica;

import pacientes.dto.Paciente;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase que gestiona la lógica de negocio de los pacientes
 * Singleton para mantener una única instancia
 * Esto consigue que haya persistencia cuando cerramos el diálogo 
 * y volvemos a abrirlo
 * @author Luis Rodrigo Martínez Tabernero
 */
public class LogicaNegocio {
    
    private static LogicaNegocio instancia;
    private final List<Paciente> listaPacientes;
    
    //Constructor
    private LogicaNegocio() {
        listaPacientes = new ArrayList<>();
    }
    
    /**
     * @return  Obtiene la única instancia del Singleton
     */
    public static LogicaNegocio getInstancia() {
        if (instancia == null) {
            instancia = new LogicaNegocio();
        }
        return instancia;
    }
    
    /**
     * Añade un nuevo paciente a la lista
     * @param paciente El paciente a añadir
     * @return true si se añadió correctamente
     */
    public boolean anadirPaciente(Paciente paciente) {
        if (paciente != null) {
            listaPacientes.add(paciente);
            return true;
        }
        return false;
    }
    
    /**
     * Actualiza un paciente existente
     * @param indice Índice del paciente en la lista
     * @param pacienteActualizado Nuevos datos del paciente
     * @return true si se actualizó correctamente
     */
    public boolean actualizarPaciente(int indice, Paciente pacienteActualizado) {
        if (indice >= 0 && indice < listaPacientes.size() && pacienteActualizado != null) {
            listaPacientes.set(indice, pacienteActualizado);
            return true;
        }
        return false;
    }
    
    /**
     * Elimina un paciente de la lista
     * @param indice Índice del paciente a eliminar
     * @return true si se eliminó correctamente
     */
    public boolean eliminarPaciente(int indice) {
        if (indice >= 0 && indice < listaPacientes.size()) {
            listaPacientes.remove(indice);
            return true;
        }
        return false;
    }
    
    /**
     * Obtenemos un paciente por su índice
     * @param indice Índice del paciente
     * @return El paciente o null si no existe
     */
    public Paciente obtenerPaciente(int indice) {
        if (indice >= 0 && indice < listaPacientes.size()) {
            return listaPacientes.get(indice);
        }
        return null;
    }
    
    /**
     * Devuelvo todos los pacientes que tengo guardados
     * @return Lista de pacientes
     */
    public List<Paciente> obtenerTodosLosPacientes() {
        return new ArrayList<>(listaPacientes);
    }
    
    /**
     * Obtiene el número total de pacientes
     * @return Cantidad de pacientes
     */
    public int getCantidadPacientes() {
        return listaPacientes.size();
    }
    
    /**
     * Verifica si la lista está vacía
     * @return true si no hay pacientes
     */
    public boolean estaVacia() {
        return listaPacientes.isEmpty();
    }
}