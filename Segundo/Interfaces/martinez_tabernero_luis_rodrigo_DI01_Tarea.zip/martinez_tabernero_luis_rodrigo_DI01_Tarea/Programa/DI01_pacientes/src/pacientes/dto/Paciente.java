package pacientes.dto;

import java.util.Date;

public class Paciente {
    private String nombre;
    private String apellidos;
    private Date fechaIngreso;
    private String diagnostico;

    public Paciente(String nombre, String apellidos, Date fechaIngreso, String diagnostico) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaIngreso = fechaIngreso;
        this.diagnostico = diagnostico;
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }

    public Date getFechaIngreso() { return fechaIngreso; }
    public void setFechaIngreso(Date fechaIngreso) { this.fechaIngreso = fechaIngreso; }

    public String getDiagnostico() { return diagnostico; }
    public void setDiagnostico(String diagnostico) { this.diagnostico = diagnostico; }
    
    //Ya no recuerdo que hace esto, lo copié del videotutorial
    public String [] toArrayString(){
    String[] s = new String[4];
    s[0] = nombre;    
    s[1] = apellidos;
    s[2] = fechaIngreso.toString();    
    s[3] = diagnostico;

    return s;
    
    }
}
