; TAREA DI07 Script de Instalación Java

!include "MUI2.nsh"

; Configuración General
Name "Buscador de Texto Java"
OutFile "Instalador_Buscador_Texto.exe"
InstallDir "$PROGRAMFILES\BuscadorTextoJava"
InstallDirRegKey HKCU "Software\BuscadorTextoJava" ""
RequestExecutionLevel admin

; Interfaz 
!define MUI_ABORTWARNING
!define MUI_ICON "${NSISDIR}\Contrib\Graphics\Icons\modern-install.ico"
!define MUI_UNICON "${NSISDIR}\Contrib\Graphics\Icons\modern-uninstall.ico"

; Páginas del asistente
!insertmacro MUI_PAGE_WELCOME                  
!insertmacro MUI_PAGE_LICENSE "licencia.txt"   
!insertmacro MUI_PAGE_COMPONENTS               
!insertmacro MUI_PAGE_DIRECTORY                
!insertmacro MUI_PAGE_INSTFILES                
!insertmacro MUI_PAGE_FINISH                   

; Páginas del Desinstalador
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

; Idioma
!insertmacro MUI_LANGUAGE "Spanish"

; Sección de Instalación
Section "Archivos del Programa" SecApp
  SectionIn RO 
  
  SetOutPath "$INSTDIR"
  
  File "DI07.jar"
  
  ; Generación del uninstaller
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  
  ; Guardar ruta 
  WriteRegStr HKCU "Software\BuscadorTextoJava" "Install_Dir" "$INSTDIR"
SectionEnd

; Sección Accesos Directos
Section "Accesos directos" SecShortcuts
  CreateDirectory "$SMPROGRAMS\Buscador de Texto Java"
  CreateShortcut "$SMPROGRAMS\Buscador de Texto Java\Buscador.lnk" "javaw.exe" "-jar $\"$INSTDIR\DI07.jar$\""
  CreateShortcut "$DESKTOP\Buscador de Texto.lnk" "javaw.exe" "-jar $\"$INSTDIR\DI07.jar$\""
SectionEnd

; Descripciones de componentes
LangString DESC_SecApp ${LANG_SPANISH} "Instala los archivos principales de la aplicación."
LangString DESC_SecShortcuts ${LANG_SPANISH} "Crea accesos directos en el escritorio y menú inicio."

!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
  !insertmacro MUI_DESCRIPTION_TEXT ${SecApp} $(DESC_SecApp)
  !insertmacro MUI_DESCRIPTION_TEXT ${SecShortcuts} $(DESC_SecShortcuts)
!insertmacro MUI_FUNCTION_DESCRIPTION_END

; Sección de Desinstalación
Section "Uninstall"
  ; Eliminar archivos
  Delete "$INSTDIR\DI07.jar"
  Delete "$INSTDIR\Uninstall.exe"
  Delete "$DESKTOP\Buscador de Texto.lnk"
  
  ; Eliminar carpetas
  RMDir /r "$SMPROGRAMS\Buscador de Texto Java"
  RMDir "$INSTDIR"
  
  DeleteRegKey HKCU "Software\BuscadorTextoJava"
SectionEnd