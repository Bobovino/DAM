package com.example.pmdm06.data.provider

import com.example.pmdm06.R
import com.example.pmdm06.data.model.Movie
import com.example.pmdm06.data.model.Platform
import com.example.pmdm06.data.model.User

object MockDataProvider {

    val defaultUser = User(email = "usuario@gmail.com", pass = "1234")

    private val usersList = mutableListOf(defaultUser)

    fun loginUser(email: String, pass: String): Boolean {
        return usersList.any { it.email == email && it.pass == pass }
    }

    fun registerUser(email: String, pass: String): Boolean {
        if (usersList.any { it.email == email }) {
            return false
        }
        usersList.add(User(email, pass))
        return true
    }

    private val netflixMovies = listOf(
        Movie(1, "El señor de los anillos", R.drawable.esdla, 5.0f, "Un hobbit debe destruir un anillo mágico.", "https://www.youtube.com/watch?v=3GJp6p_mgPo"),
        Movie(2, "El Padrino", R.drawable.elpadrino, 4.8f, "La historia de la familia criminal Corleone.", "https://www.youtube.com/watch?v=v72XprPxy3E"),
        Movie(3, "El caballero oscuro", R.drawable.caballerooscuro, 4.9f, "Batman se enfrenta al Joker.", "https://www.youtube.com/watch?v=EXeTwQWrcwY"),
        Movie(4, "Jurassic Park", R.drawable.jurassicpark, 4.5f, "Dinosaurios clonados escapan en un parque.", "https://www.youtube.com/watch?v=lc0UehYemQA")
    )

    private val hboMovies = listOf(
        Movie(5, "Avatar", R.drawable.avatar, 4.2f, "Un marine parapléjico es enviado a la luna Pandora.", "https://www.youtube.com/watch?v=5PSNL1qE6VY"),
        Movie(6, "Pulp Fiction", R.drawable.pulpfiction, 4.7f, "Historias entrelazadas de criminales en Los Ángeles.", "https://www.youtube.com/watch?v=s7EdQ4FqbhY"),
        Movie(7, "La guerra de los mundos", R.drawable.guerramundos, 4.0f, "Invasión alienígena a la Tierra.", "https://www.youtube.com/watch?v=vby8BBThG7s")
    )

    val platforms = listOf(
        Platform(1, "Netflix", R.drawable.netflix, netflixMovies),
        Platform(2, "HBO Max", R.drawable.hbo, hboMovies)
    )

    fun getPlatformById(id: Int): Platform? {
        return platforms.find { it.id == id }
    }

    fun getMovieById(id: Int): Movie? {
        return platforms.flatMap { it.movies }.find { it.id == id }
    }
}
