package com.example.pmdm06.data.model

data class Platform(
    val id: Int,
    val name: String,
    val logoResId: Int,
    val movies: List<Movie>
)
