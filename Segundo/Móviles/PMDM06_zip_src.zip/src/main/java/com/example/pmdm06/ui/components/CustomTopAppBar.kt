package com.example.pmdm06.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.res.stringResource
import com.example.pmdm06.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomTopAppBar(
    title: String,
    showBackArrow: Boolean = false,
    onBackClick: () -> Unit = {},
    showMenu: Boolean = false,
    onNavigateToHelp: () -> Unit = {},
    onNavigateToAbout: () -> Unit = {}
) {
    var menuExpanded by remember { mutableStateOf(false) }

    TopAppBar(
        title = { Text(text = title) },
        navigationIcon = {
            if (showBackArrow) {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = stringResource(id = R.string.back_button_description)
                    )
                }
            }
        },
        actions = {
            if (showMenu) {
                IconButton(onClick = { menuExpanded = !menuExpanded }) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Opciones"
                    )
                }
                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(stringResource(id = R.string.menu_help)) },
                        onClick = {
                            menuExpanded = false
                            onNavigateToHelp()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(id = R.string.menu_about)) },
                        onClick = {
                            menuExpanded = false
                            onNavigateToAbout()
                        }
                    )
                }
            }
        }
    )
}
