package com.example.pmdm06.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.pmdm06.ui.screens.auth.LoginScreen
import com.example.pmdm06.ui.screens.auth.RegisterScreen
import com.example.pmdm06.ui.screens.home.PlatformListScreen
import com.example.pmdm06.ui.screens.info.AboutScreen
import com.example.pmdm06.ui.screens.info.HelpScreen
import com.example.pmdm06.ui.screens.movies.MovieDetailScreen
import com.example.pmdm06.ui.screens.movies.MovieListScreen
import com.example.pmdm06.ui.screens.player.VideoPlayerScreen
import com.example.pmdm06.ui.screens.splash.SplashScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = AppScreens.Splash.route
    ) {

        composable(AppScreens.Splash.route) {
            SplashScreen(onStartClick = {
                navController.navigate(AppScreens.Login.route) {
                    popUpTo(AppScreens.Splash.route) { inclusive = true }
                }
            })
        }

        composable(AppScreens.Login.route) {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(AppScreens.PlatformList.route) {
                        popUpTo(AppScreens.Login.route) { inclusive = true }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate(AppScreens.Register.route)
                }
            )
        }

        composable(AppScreens.Register.route) {
            RegisterScreen(
                onRegisterSuccess = {
                    navController.navigate(AppScreens.PlatformList.route) {
                        popUpTo(AppScreens.Login.route) { inclusive = true }
                    }
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(AppScreens.PlatformList.route) {
            PlatformListScreen(
                onPlatformClick = { platformId ->
                    navController.navigate(AppScreens.MovieList.createRoute(platformId))
                },
                onNavigateToHelp = { navController.navigate(AppScreens.Help.route) },
                onNavigateToAbout = { navController.navigate(AppScreens.About.route) }
            )
        }

        composable(
            route = AppScreens.MovieList.route,
            arguments = listOf(navArgument("platformId") { type = NavType.IntType })
        ) { backStackEntry ->
            val platformId = backStackEntry.arguments?.getInt("platformId") ?: 0
            MovieListScreen(
                platformId = platformId,
                onMovieClick = { movieId ->
                    navController.navigate(AppScreens.MovieDetail.createRoute(movieId))
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = AppScreens.MovieDetail.route,
            arguments = listOf(navArgument("movieId") { type = NavType.IntType })
        ) { backStackEntry ->
            val movieId = backStackEntry.arguments?.getInt("movieId") ?: 0
            MovieDetailScreen(
                movieId = movieId,
                onPlayClick = {
                    navController.navigate(AppScreens.VideoPlayer.createRoute(movieId))
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = AppScreens.VideoPlayer.route,
            arguments = listOf(navArgument("movieId") { type = NavType.IntType })
        ) { backStackEntry ->
            val movieId = backStackEntry.arguments?.getInt("movieId") ?: 0
            VideoPlayerScreen(
                movieId = movieId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(AppScreens.Help.route) {
            HelpScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(AppScreens.About.route) {
            AboutScreen(onNavigateBack = { navController.popBackStack() })
        }
    }
}
