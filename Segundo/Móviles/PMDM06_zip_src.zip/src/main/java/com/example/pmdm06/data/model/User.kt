package com.example.pmdm06.data.model

data class User(
    val email: String,
    val pass: String,
    val username: String? = null,
    val phone: String? = null
)
