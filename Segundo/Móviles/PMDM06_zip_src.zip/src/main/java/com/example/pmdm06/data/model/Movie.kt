package com.example.pmdm06.data.model

data class Movie(
    val id: Int,
    val title: String,
    val coverResId: Int,
    val rating: Float,
    val summary: String,
    val videoUrl: String
)
