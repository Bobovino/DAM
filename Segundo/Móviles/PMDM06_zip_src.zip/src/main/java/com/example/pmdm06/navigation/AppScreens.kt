package com.example.pmdm06.navigation

sealed class AppScreens(val route: String) {

    object Splash : AppScreens("splash_screen")

    object Login : AppScreens("login_screen")

    object Register : AppScreens("register_screen")

    object PlatformList : AppScreens("platform_list_screen")

    object Help : AppScreens("help_screen")

    object About : AppScreens("about_screen")

    object MovieList : AppScreens("movie_list_screen/{platformId}") {
        fun createRoute(platformId: Int) = "movie_list_screen/$platformId"
    }

    object MovieDetail : AppScreens("movie_detail_screen/{movieId}") {
        fun createRoute(movieId: Int) = "movie_detail_screen/$movieId"
    }

    object VideoPlayer : AppScreens("video_player_screen/{movieId}") {
        fun createRoute(movieId: Int) = "video_player_screen/$movieId"
    }
}
