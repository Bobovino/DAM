package com.example.tarea3_1_suma;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText et1, et2;
    private Button btn;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Vinculación por ID
        et1 = findViewById(R.id.etNumero1);
        et2 = findViewById(R.id.etNumero2);
        btn = findViewById(R.id.btnSumar);
        result = findViewById(R.id.tvResultado);

        // Captura de evento programática
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sumar();
            }
        });
    }

    private void sumar() {
        try {
            // Obtenemos los datos para después mostrarlos
            int n1 = Integer.parseInt(et1.getText().toString());
            int n2 = Integer.parseInt(et2.getText().toString());

            int suma = n1 + n2;

            // Mostrar resultado
            result.setText(String.valueOf(suma));

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Error: introduce números enteros", Toast.LENGTH_SHORT).show();
            result.setText("0");
        }
    }
}