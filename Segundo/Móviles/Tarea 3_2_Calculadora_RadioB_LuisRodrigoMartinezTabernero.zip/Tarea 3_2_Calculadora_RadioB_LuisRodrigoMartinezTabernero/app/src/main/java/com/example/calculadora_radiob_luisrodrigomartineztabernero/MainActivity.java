package com.example.calculadora_radiob_luisrodrigomartineztabernero;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText et1, et2;
    private RadioGroup rgGrupo;
    private TextView tvRes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = findViewById(R.id.etOperando1);
        et2 = findViewById(R.id.etOperando2);
        rgGrupo = findViewById(R.id.rgOperaciones);
        tvRes = findViewById(R.id.tvResultado);

        rgGrupo.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                calcular(checkedId);
            }
        });
    }

    //Vamos a calcular cuando se seleccione una operación. Np es la mejor UX, pero es lo que se pide.
    private void calcular(int idSeleccionado) {
        String txt1 = et1.getText().toString();
        String txt2 = et2.getText().toString();

        if (txt1.isEmpty() || txt2.isEmpty()) {
            Toast.makeText(this, "Faltan números", Toast.LENGTH_SHORT).show();
            rgGrupo.setOnCheckedChangeListener(null);
            rgGrupo.clearCheck();
            rgGrupo.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    calcular(checkedId);
                }
            });
            return;
        }

        try {
            double n1 = Double.parseDouble(txt1);
            double n2 = Double.parseDouble(txt2);
            double resultado = 0;

            if (idSeleccionado == R.id.rbSuma) {
                resultado = n1 + n2;
            } else if (idSeleccionado == R.id.rbResta) {
                resultado = n1 - n2;
            } else if (idSeleccionado == R.id.rbMulti) {
                resultado = n1 * n2;
            } else if (idSeleccionado == R.id.rbDiv) {
                if (n2 == 0) {
                    tvRes.setText("Error: Div/0");
                    Toast.makeText(this, "Cuidado no se puede dividir por 0. Cambie el operando 2", Toast.LENGTH_SHORT).show();
                    return;
                }
                resultado = n1 / n2;
            }

            tvRes.setText(String.format("%.2f", resultado));

        } catch (NumberFormatException e) {
            tvRes.setText("Error");
            Toast.makeText(this, "Formato numérico incorrecto", Toast.LENGTH_SHORT).show();
        }
    }
}
