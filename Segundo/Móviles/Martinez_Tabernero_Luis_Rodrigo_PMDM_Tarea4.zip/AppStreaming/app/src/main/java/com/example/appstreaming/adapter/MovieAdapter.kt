package com.example.appstreaming.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.appstreaming.R
import com.example.appstreaming.model.Pelicula

class MovieAdapter(
    private val listaPeliculas: List<Pelicula>,
    private val onMovieClick: (Pelicula) -> Unit
) : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    class MovieViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivCover: ImageView = view.findViewById(R.id.ivMovieCover)
        val tvTitle: TextView = view.findViewById(R.id.tvMovieTitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pelicula, parent, false)
        return MovieViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val pelicula = listaPeliculas[position]
        holder.tvTitle.text = pelicula.titulo
        holder.ivCover.setImageResource(pelicula.imagenResId)

        holder.itemView.setOnClickListener {
            onMovieClick(pelicula)
        }
    }

    override fun getItemCount(): Int = listaPeliculas.size
}