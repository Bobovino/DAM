package com.example.appstreaming.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.appstreaming.R
import com.example.appstreaming.model.Plataforma


class PlatformAdapter(
    private val listaPlataformas: List<Plataforma>,
    private val onPlatformClick: (Plataforma) -> Unit
) : RecyclerView.Adapter<PlatformAdapter.PlatformViewHolder>() {


    class PlatformViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivLogo: ImageView = view.findViewById(R.id.ivPlatformLogo)
        val tvName: TextView = view.findViewById(R.id.tvPlatformName)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlatformViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_plataforma, parent, false)
        return PlatformViewHolder(view)
    }


    override fun onBindViewHolder(holder: PlatformViewHolder, position: Int) {
        val plataforma = listaPlataformas[position]


        holder.tvName.text = plataforma.nombre
        holder.ivLogo.setImageResource(plataforma.logoResId)


        holder.itemView.setOnClickListener {
            onPlatformClick(plataforma)
        }
    }


    override fun getItemCount(): Int = listaPlataformas.size
}