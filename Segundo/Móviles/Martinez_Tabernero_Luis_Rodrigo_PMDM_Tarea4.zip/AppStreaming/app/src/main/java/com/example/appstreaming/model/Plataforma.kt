package com.example.appstreaming.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Plataforma(
    val id: Int,
    val nombre: String,
    val logoResId: Int,
    val peliculas: List<Pelicula>
) : Parcelable