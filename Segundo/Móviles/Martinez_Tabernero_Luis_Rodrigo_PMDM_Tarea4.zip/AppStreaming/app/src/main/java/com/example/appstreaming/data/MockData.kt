package com.example.appstreaming.data

import com.example.appstreaming.R
import com.example.appstreaming.model.Pelicula
import com.example.appstreaming.model.Usuario
import com.example.appstreaming.model.Plataforma

object MockData {

    // Simulo una base de datos de usuarios
    val usuarios: MutableList<Usuario> = mutableListOf(
        Usuario("usuario@gmail.com", "1234") // Usuario por defecto
    )

    // Variable para saber quién está logueado
    var usuarioActual: Usuario? = null


    private val peliculasNetflix = listOf(
        Pelicula(1, "Stranger Things", "Un grupo de niños en los años 80 se enfrenta a fuerzas sobrenaturales en su pueblo.", "Hermanos Duffer", 4.8, R.drawable.stranger_things),
        Pelicula(2, "The Crown", "La vida de la Reina Isabel II desde su juventud hasta la actualidad.", "Peter Morgan", 4.7, R.drawable.the_crown),
        Pelicula(3, "Black Mirror", "Serie antológica que explora un futuro distópico y la relación con la tecnología.", "Charlie Brooker", 4.6, R.drawable.black_mirror),
        Pelicula(4, "La Casa de Papel", "Un grupo de criminales lleva a cabo el mayor atraco de la historia en la Fábrica Nacional de Moneda y Timbre.", "Álex Pina", 4.5, R.drawable.la_casa_de_papel),
        Pelicula(5, "The Witcher", "Un cazador de monstruos lucha por encontrar su lugar en un mundo donde las personas suelen ser más perversas que las bestias.", "Lauren Schmidt Hissrich", 4.4, R.drawable.the_witcher),
        Pelicula(6, "Narcos", "La historia real de los capos de la droga en Colombia y los esfuerzos de la ley para detenerlos.", "Chris Brancato", 4.3, R.drawable.narcos),
        Pelicula(7, "Sex Education", "Un adolescente socialmente torpe y su madre sexóloga abren una clínica de terapia sexual en su escuela.", "Laurie Nunn", 4.2, R.drawable.sex_education),
        Pelicula(8, "Dark", "Misterio y viajes en el tiempo en un pequeño pueblo alemán tras la desaparición de un niño.", "Baran bo Odar", 4.7, R.drawable.dark),
        Pelicula(9, "You", "Un librero desarrolla una peligrosa obsesión con una clienta.", "Greg Berlanti", 4.0, R.drawable.you)
    )


    private val peliculasHBO = listOf(
        Pelicula(10, "Juego de Tronos", "Nueve familias nobles luchan por el control de los Siete Reinos de Westeros.", "David Benioff & D. B. Weiss", 4.9, R.drawable.juego_de_tronos),
        Pelicula(11, "Chernobyl", "Miniserie sobre el desastre nuclear de Chernóbil y sus consecuencias.", "Craig Mazin", 4.8, R.drawable.chernobyl),
        Pelicula(12, "Euphoria", "Un grupo de adolescentes navega por un mundo de drogas, sexo y violencia.", "Sam Levinson", 4.5, R.drawable.euphoria),
        Pelicula(13, "Succession", "La familia Roy lucha por el control de su imperio mediático.", "Jesse Armstrong", 4.7, R.drawable.succession),
        Pelicula(14, "Westworld", "Un parque temático futurista poblado por androides que comienzan a tomar conciencia.", "Jonathan Nolan & Lisa Joy", 4.4, R.drawable.westworld),
        Pelicula(15, "The Last of Us", "Dos supervivientes cruzan Estados Unidos tras un apocalipsis fúngico.", "Craig Mazin & Neil Druckmann", 4.8, R.drawable.the_last_of_us),
        Pelicula(16, "Big Little Lies", "Un asesinato saca a la luz secretos en una comunidad californiana.", "David E. Kelley", 4.3, R.drawable.big_little_lies),
        Pelicula(17, "True Detective", "Detectives investigan crímenes complejos a lo largo de varias temporadas.", "Nic Pizzolatto", 4.6, R.drawable.true_detective),
        Pelicula(18, "Barry", "Un asesino a sueldo descubre su pasión por la actuación.", "Bill Hader & Alec Berg", 4.1, R.drawable.barry)
    )


    val plataformas = listOf(
        Plataforma(1, "Netflix", R.drawable.netflix, peliculasNetflix),
        Plataforma(2, "HBO Max", R.drawable.hbo, peliculasHBO)
    )


    fun validarUsuario(email: String, pass: String): Boolean {
        return usuarios.any { it.email == email && it.password == pass }
    }


    fun registrarUsuario(email: String, pass: String): Boolean {
        if (usuarios.any { it.email == email }) return false
        usuarios.add(Usuario(email, pass))
        return true
    }
}