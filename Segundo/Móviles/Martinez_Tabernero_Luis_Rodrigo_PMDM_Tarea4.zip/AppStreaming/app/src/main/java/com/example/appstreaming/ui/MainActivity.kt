package com.example.appstreaming.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.appstreaming.R
import com.example.appstreaming.data.MockData

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        supportActionBar?.hide()

        val btnStart = findViewById<Button>(R.id.btnStart)


        btnStart.setOnClickListener {

            if (MockData.usuarioActual != null) {

                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)
            } else {

                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
            }
        }
    }
}