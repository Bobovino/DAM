package com.example.appstreaming.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView
import com.example.appstreaming.R
import com.example.appstreaming.adapter.MovieAdapter
import com.example.appstreaming.model.Pelicula
import com.example.appstreaming.model.Plataforma

class MovieListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_list)
        val plataforma = intent.getParcelableExtra<Plataforma>("extra_plataforma")
        val tvHeader = findViewById<TextView>(R.id.tvPlatformHeader)
        val rvMovies = findViewById<RecyclerView>(R.id.rvMovies)
        if (plataforma != null) {
            tvHeader.text = plataforma.nombre
            rvMovies.layoutManager = GridLayoutManager(this, 3)
            val adapter = MovieAdapter(plataforma.peliculas) { pelicula ->
                navigateToDetail(pelicula)
            }
            rvMovies.adapter = adapter
        }
    }

    private fun navigateToDetail(pelicula: Pelicula) {
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra("extra_pelicula", pelicula)
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu): Boolean {
        menuInflater.inflate(R.menu.menu_home, menu)
        return true
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_help -> {
                startActivity(android.content.Intent(this, HelpActivity::class.java))
                return true
            }
            R.id.action_about -> {
                startActivity(android.content.Intent(this, AboutActivity::class.java))
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}