package com.example.appstreaming.ui

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.appstreaming.R
import com.example.appstreaming.adapter.PlatformAdapter
import com.example.appstreaming.data.MockData
import com.example.appstreaming.model.Plataforma

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        val rvPlatforms = findViewById<RecyclerView>(R.id.rvPlatforms)

        rvPlatforms.layoutManager = LinearLayoutManager(this)

        val adapter = PlatformAdapter(MockData.plataformas) { plataforma ->
            navigateToMovies(plataforma)
        }

        rvPlatforms.adapter = adapter
    }

    private fun navigateToMovies(plataforma: Plataforma) {
        val intent = Intent(this, MovieListActivity::class.java)
        intent.putExtra("extra_plataforma", plataforma)
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_home, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_help -> {
                startActivity(Intent(this, HelpActivity::class.java))
                return true
            }
            R.id.action_about -> {
                startActivity(Intent(this, AboutActivity::class.java))
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}