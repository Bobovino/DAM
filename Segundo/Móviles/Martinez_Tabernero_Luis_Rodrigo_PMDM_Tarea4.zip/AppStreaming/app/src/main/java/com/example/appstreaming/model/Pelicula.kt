package com.example.appstreaming.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Pelicula(
    val id: Int,
    val titulo: String,
    val descripcion: String,
    val director: String,
    val puntuacion: Double,
    val imagenResId: Int
) : Parcelable