package com.example.appstreaming.ui

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.appstreaming.R
import com.example.appstreaming.model.Pelicula

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val pelicula = intent.getParcelableExtra<Pelicula>("extra_pelicula")
        val ivCover = findViewById<ImageView>(R.id.ivDetailCover)
        val tvTitle = findViewById<TextView>(R.id.tvDetailTitle)
        val tvDirector = findViewById<TextView>(R.id.tvDetailDirector)
        val tvRating = findViewById<TextView>(R.id.tvDetailRating)
        val tvDesc = findViewById<TextView>(R.id.tvDetailDescription)
        if (pelicula != null) {
            title = pelicula.titulo
            ivCover.setImageResource(pelicula.imagenResId)
            tvTitle.text = pelicula.titulo
            tvDirector.text = "Director: ${pelicula.director}"
            tvRating.text = "\u2b50 ${pelicula.puntuacion}/5"
            tvDesc.text = pelicula.descripcion
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_help -> {
                startActivity(android.content.Intent(this, HelpActivity::class.java))
                return true
            }
            R.id.action_about -> {
                startActivity(android.content.Intent(this, AboutActivity::class.java))
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}