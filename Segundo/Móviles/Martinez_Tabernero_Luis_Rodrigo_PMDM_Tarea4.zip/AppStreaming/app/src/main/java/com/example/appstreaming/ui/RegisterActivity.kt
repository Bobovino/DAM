package com.example.appstreaming.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appstreaming.R
import com.example.appstreaming.data.MockData
import com.example.appstreaming.model.Usuario

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etEmail = findViewById<EditText>(R.id.etRegisterEmail)
        val etPass = findViewById<EditText>(R.id.etRegisterPassword)
        val etConfPass = findViewById<EditText>(R.id.etConfirmPassword)
        val btnRegister = findViewById<Button>(R.id.btnRegister)

        btnRegister.setOnClickListener {
            val email = etEmail.text.toString()
            val pass = etPass.text.toString()
            val confPass = etConfPass.text.toString()


            if (email.isEmpty() || pass.isEmpty() || confPass.isEmpty()) {
                Toast.makeText(this, R.string.error_empty_fields, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            if (pass != confPass) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            if (MockData.registrarUsuario(email, pass)) {
                Toast.makeText(this, "Usuario registrado con éxito", Toast.LENGTH_SHORT).show()

                MockData.usuarioActual = Usuario(email, pass)

                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)

                finish()
            } else {
                Toast.makeText(this, R.string.error_user_exists, Toast.LENGTH_SHORT).show()
            }
        }
    }
}