package com.example.pmdm07.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.google.maps.android.compose.MapType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopBarMenu(
    onBorrarClick: () -> Unit,
    onTipoMapaClick: (MapType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    TopAppBar(
        title = { Text("Ubicación en tiempo real") },
        actions = {
            IconButton(onClick = { expanded = true }) {
                Icon(Icons.Default.MoreVert, contentDescription = "Abrir el menú")
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Borrar ubicaciones") },
                    onClick = {
                        onBorrarClick()
                        expanded = false
                    }
                )
                DropdownMenuItem(
                    text = { Text("Híbrido") },
                    onClick = {
                        onTipoMapaClick(MapType.HYBRID)
                        expanded = false
                    }
                )
                DropdownMenuItem(
                    text = { Text("Normal") },
                    onClick = {
                        onTipoMapaClick(MapType.NORMAL)
                        expanded = false
                    }
                )
            }
        }
    )
}