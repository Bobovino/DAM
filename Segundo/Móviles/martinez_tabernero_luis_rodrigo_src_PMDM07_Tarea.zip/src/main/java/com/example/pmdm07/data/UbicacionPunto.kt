package com.example.pmdm07.data

import com.google.android.gms.maps.model.LatLng

data class UbicacionPunto(
    val coordenadas: LatLng,
    val timestamp: String,
    val esPrimero: Boolean = false
)