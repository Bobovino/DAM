package com.example.pmdm07

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.pmdm07.ui.MapScreen
import com.example.pmdm07.ui.theme.PMDM07Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PMDM07Theme {
                MapScreen()
            }
        }
    }
}
