package com.example.pmdm07.ui

import android.Manifest
import android.annotation.SuppressLint
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.location.*
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import com.example.pmdm07.ui.components.TopBarMenu

@SuppressLint("MissingPermission")
@Composable
fun MapScreen(viewModel: MapViewModel = viewModel()) {
    val context = LocalContext.current
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }
    val cameraPositionState = rememberCameraPositionState()

    var hasLocationPermission by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasLocationPermission = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    DisposableEffect(hasLocationPermission) {
        var locationCallback: LocationCallback? = null
        if (hasLocationPermission) {
            // Kriterien: 30 Sekunden (30000ms) ODER 2 Meter Distanz
            val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 30000L)
                .setMinUpdateDistanceMeters(2f)
                .build()

            locationCallback = object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    result.lastLocation?.let { location ->
                        val latLng = LatLng(location.latitude, location.longitude)
                        viewModel.agregarUbicacion(latLng)
                        cameraPositionState.position = CameraPosition.fromLatLngZoom(latLng, 16f)
                    }
                }
            }
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())
        }

        onDispose {
            locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }
        }
    }

    Scaffold(
        topBar = {
            TopBarMenu(
                onBorrarClick = { viewModel.borrarUbicaciones() },
                onTipoMapaClick = { viewModel.cambiarTipoMapa(it) }
            )
        }
    ) { paddingValues ->
        GoogleMap(
            modifier = Modifier.padding(paddingValues).fillMaxSize(),
            cameraPositionState = cameraPositionState,
            properties = MapProperties(
                mapType = viewModel.tipoMapa,
                isMyLocationEnabled = hasLocationPermission
            )
        ) {
            if (viewModel.puntos.size > 1) {
                Polyline(
                    points = viewModel.puntos.map { it.coordenadas },
                    color = Color.Red,
                    width = 8f
                )
            }

            viewModel.puntos.forEachIndexed { index, punto ->
                val titulo = when {
                    index == 0 -> "Inicio trayecto ${punto.timestamp}"
                    index == viewModel.puntos.size - 1 -> "Ubicación actual - ${punto.timestamp}"
                    else -> "Ubicación - ${punto.timestamp}"
                }
                Marker(
                    state = MarkerState(position = punto.coordenadas),
                    title = titulo
                )
            }
        }
    }
}