package com.example.pmdm07.ui

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.MapType
import com.example.pmdm07.data.UbicacionPunto
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MapViewModel : ViewModel() {
    private val _puntos = mutableStateListOf<UbicacionPunto>()
    val puntos: List<UbicacionPunto> = _puntos

    var tipoMapa by mutableStateOf(MapType.NORMAL)
        private set

    fun agregarUbicacion(latLng: LatLng) {
        val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault())
        val timestamp = sdf.format(Date())
        val esPrimero = _puntos.isEmpty()

        _puntos.add(UbicacionPunto(latLng, timestamp, esPrimero))
    }

    fun borrarUbicaciones() {
        _puntos.clear()
    }

    fun cambiarTipoMapa(tipo: MapType) {
        tipoMapa = tipo
    }
}