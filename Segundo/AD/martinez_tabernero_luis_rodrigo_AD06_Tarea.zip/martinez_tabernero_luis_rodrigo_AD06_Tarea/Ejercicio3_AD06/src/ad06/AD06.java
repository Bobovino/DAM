package ad06;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQPreparedExpression;
import javax.xml.xquery.XQResultSequence;
import net.xqj.exist.ExistXQDataSource;

/**
 *
 * @author rodry
 */
public class AD06 {

    public static void main(String[] args) {
        try {
            //Configuramos el Datasource, y la conexión
            XQDataSource xqs = new ExistXQDataSource();
            xqs.setProperty("serverName", "localhost");
            xqs.setProperty("port", "8083"); // Cambié el puerto porque ya estaba en uso
            xqs.setProperty("user", "admin");
            xqs.setProperty("password", "31415926"); //Contraseña sencilla
            
            //Nos conectamos
            XQConnection con = xqs.getConnection();
            
            // Guardamos la consulta xQuery en un String
            // Consiste en buscar en carta.xml los platos cuyo tipo sea 'postre' y devuelve su nombre
            String query = "for $p in doc('/db/ColecTareaAD6/carta.xml')//plato[tipo='postre'] return $p/nombre/text()";
            
            // Ejecutamos la consulta
            XQPreparedExpression expr = con.prepareExpression(query);
            XQResultSequence result = expr.executeQuery();
            
            // Imprimimos los resultados con un bucle
            System.out.println("--- LISTA DE POSTRES ---");
            while (result.next()) {
                System.out.println("- " + result.getItemAsString(null));
            }
            
            // Cerramos y añadimos un try catch para gestionar excepciones
            result.close();
            expr.close();
            con.close();
            
        } catch (XQException e) {
            System.out.println("Error de conexión o en la consulta: " + e.getMessage());
        }
    }
    
}
