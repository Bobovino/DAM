package ad03; 

import java.sql.*;

// Antes la he llamado GestionAerolinea pero no me apetece refactorizar
public class AD03 {

    // La conexión la pongo estática para poder usarla en todos los métodos sin pasarla por parámetro
    static Connection conexion;

    // Datos de mi base de datos (Oracle XE local)
    static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:XE";
    static final String USER = "SYSTEM"; 
    static final String PASS = "oracle"; 

    public static void main(String[] args) {

        try {
            // Cargar el driver de Oracle
            Class.forName("oracle.jdbc.OracleDriver");

            // Conecto a la BD
            System.out.println("Conectando a la base de datos Oracle...");
            conexion = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Conexión establecida.\n");

            // --- Ejecución de los apartados de la tarea ---

            // A. Sacar información de la BD
            metainformacionBD();

            // B. Listar todos los pasajeros
            mostrarTablaPasajeros();

            // C. Buscar pasajeros de un vuelo concreto
            verPasajerosDeVuelo("IB-SP-4567");

            // D. Insertar vuelo nuevo (con PreparedStatement)
            // Le paso los datos "a capón" para probar que funciona
            insertarVuelo("V-TEST-01", "01/01/24-12:00", "LONDRES", "MADRID", 20, 100, 100, 20);

            // E. Actualizar plazas (quitar fumadores)
            modificarPlazasFumador();

            // F. Borrar el vuelo de prueba para dejar la BD limpia
            borrarVuelo("V-TEST-01");

            // Cierro la conexión al terminar
            conexion.close();
            System.out.println("\nConexión cerrada correctamente.");

        } catch (ClassNotFoundException e) {
            System.err.println("Error: No encuentro el jar del Driver.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Ha petado el SQL: " + e.getMessage());
            System.err.println("El código de error es: " + e.getErrorCode());
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("Error raro no controlado");
            e.printStackTrace();
        }
    }

    // 1. Método para ver info de la BD y las tablas que tengo
    public static void metainformacionBD() throws SQLException {
        DatabaseMetaData dbmd = conexion.getMetaData();
        ResultSet resul = null;

        String nombre = dbmd.getDatabaseProductName();
        String driver = dbmd.getDriverName();
        String url = dbmd.getURL();
        String usuario = dbmd.getUserName();

        System.out.println("--- INFORMACIÓN SOBRE LA BASE DE DATOS ---");
        System.out.printf("Nombre : %s %n", nombre);
        System.out.printf("Driver : %s %n", driver);
        System.out.printf("URL    : %s %n", url);
        System.out.printf("Usuario: %s %n", usuario);

        System.out.println("--- Listado de Tablas del Usuario ---");
        
        // OJO: En Oracle hay que filtrar por mi usuario (SYSTEM) porque si pongo null
        // me salen cientos de tablas de sistema y no encuentro las mías.
        // También filtro por "TABLE" para que no salgan vistas.
        resul = dbmd.getTables(null, usuario, null, new String[]{"TABLE"});

        while (resul.next()) {
            String tabla = resul.getString("TABLE_NAME"); 
            String tipo = resul.getString("TABLE_TYPE");  
            System.out.printf("Tipo: %s - Nombre: %s %n", tipo, tabla);
        }
        System.out.println();
        if (resul != null) resul.close();
    }

    // 2. Método para listar pasajeros
    public static void mostrarTablaPasajeros() throws SQLException {
        Statement sentencia = conexion.createStatement();
        String sql = "SELECT * FROM PASAJEROS";
        ResultSet resul = sentencia.executeQuery(sql);

        System.out.println("--- REGISTROS DE LA TABLA PASAJEROS ---");
        System.out.printf("%-10s %-15s %-10s %-10s %n", "NUMERO", "COD_VUELO", "PLAZA", "FUMADOR");
        System.out.println("-------------------------------------------------------");

        while (resul.next()) {
            System.out.printf("%-10d %-15s %-10s %-10s %n",
                    resul.getInt("NUM"),
                    resul.getString("COD_VUELO"),
                    resul.getString("TIPO_PLAZA"),
                    resul.getString("FUMADOR"));
        }
        System.out.println();
        resul.close();
        sentencia.close();
    }

    // 3. Buscar pasajeros por código
    public static void verPasajerosDeVuelo(String codVuelo) throws SQLException {
        // Uso PreparedStatement porque es más seguro y limpio que concatenar Strings
        String sql = "SELECT * FROM PASAJEROS WHERE COD_VUELO = ?";
        PreparedStatement sentencia = conexion.prepareStatement(sql);
        sentencia.setString(1, codVuelo);

        ResultSet resul = sentencia.executeQuery();

        System.out.println("--- PASAJEROS DEL VUELO: " + codVuelo + " ---");
        boolean hayDatos = false;
        while (resul.next()) {
            hayDatos = true;
            System.out.printf("Pasajero Nº: %d, Plaza: %s %n",
                    resul.getInt("NUM"), resul.getString("TIPO_PLAZA"));
        }

        if (!hayDatos) {
            System.out.println("No he encontrado pasajeros para este vuelo.");
        }
        System.out.println();
        resul.close();
        sentencia.close();
    }

    // 4. Insertar vuelo
    public static void insertarVuelo(String cod, String hora, String dest, String proc,
                                     int pFum, int pNoFum, int pTur, int pPri) throws SQLException {
        try {
            String sql = "INSERT INTO VUELOS VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement sentencia = conexion.prepareStatement(sql);

            // Voy rellenando los interrogantes
            sentencia.setString(1, cod);
            sentencia.setString(2, hora);
            sentencia.setString(3, dest);
            sentencia.setString(4, proc);
            sentencia.setInt(5, pFum);
            sentencia.setInt(6, pNoFum);
            sentencia.setInt(7, pTur);
            sentencia.setInt(8, pPri);

            System.out.println("Insertando vuelo: " + cod + "...");
            int filas = sentencia.executeUpdate();
            System.out.println("VUELO INSERTADO. Filas afectadas: " + filas);
            System.out.println();
            sentencia.close();

        } catch (SQLException e) {
            // El error 1 en Oracle significa clave duplicada (Unique Constraint)
            if (e.getErrorCode() == 1) {
                System.out.println("ERROR: El vuelo " + cod + " ya existe, no puedo insertarlo otra vez.");
            } else {
                throw e; // Si es otro error, que salte
            }
        }
    }

    // 5. Quitar plazas de fumador
    public static void modificarPlazasFumador() throws SQLException {
        // La lógica es: Sumo las de fumador a las de no fumador y luego pongo fumador a 0
        String sql = "UPDATE VUELOS SET "
                   + "PLAZAS_NO_FUMADOR = PLAZAS_NO_FUMADOR + PLAZAS_FUMADOR, "
                   + "PLAZAS_FUMADOR = 0 "
                   + "WHERE PLAZAS_FUMADOR > 0";

        Statement sentencia = conexion.createStatement();
        int filas = sentencia.executeUpdate(sql);

        System.out.println("--- MODIFICACIÓN DE PLAZAS (NO FUMADORES) ---");
        if (filas > 0) {
            System.out.println("He actualizado " + filas + " vuelos para que sean libres de humo.");
        } else {
            System.out.println("No había nada que actualizar.");
        }
        System.out.println();
        sentencia.close();
    }

    // 6. Borrar vuelo
    public static void borrarVuelo(String codVuelo) throws SQLException {
        String sql = "DELETE FROM VUELOS WHERE COD_VUELO = ?";
        PreparedStatement sentencia = conexion.prepareStatement(sql);
        sentencia.setString(1, codVuelo);

        System.out.println("Borrando vuelo: " + codVuelo + "...");
        int filas = sentencia.executeUpdate();

        if (filas == 1) {
            System.out.println("VUELO BORRADO CORRECTAMENTE.");
        } else {
            System.out.println("NO SE PUDO BORRAR (Igual no existe).");
        }
        System.out.println();
        sentencia.close();
    }
}