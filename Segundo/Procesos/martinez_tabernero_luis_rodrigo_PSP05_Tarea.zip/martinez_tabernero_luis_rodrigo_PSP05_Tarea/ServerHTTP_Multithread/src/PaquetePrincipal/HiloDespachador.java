package PaquetePrincipal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author rodry
 */
public class HiloDespachador extends Thread {
    private final Socket socketCliente;
    
    public HiloDespachador(Socket socketCliente){
        this.socketCliente = socketCliente;
    }
    
    @Override
  public void run() { 
    try { 
      System.out.println("Atendiendo al cliente en el hilo: " + Thread.currentThread().getName());
      procesaPeticion(this.socketCliente); 
      // cierra la conexión entrante
      this.socketCliente.close();
      System.out.println("Cliente atendido y conexión cerrada.");
    } catch (IOException ex) { 
      System.err.println("Error de entrada/salida al procesar la petición: " + ex.getMessage());
    }
  }
    
/**
   *****************************************************************************
   * procesa la petición recibida
   *
   * @throws IOException
   */
  private static void procesaPeticion(Socket socketCliente) throws IOException {
    //variables locales
    String peticion;
    String html;

    //Flujo de entrada
    InputStreamReader inSR = new InputStreamReader(
    socketCliente.getInputStream());
    //espacio en memoria para la entrada de peticiones
    BufferedReader bufLeer = new BufferedReader(inSR);

    //objeto de java.io que entre otras características, permite escribir 
    //'línea a línea' en un flujo de salida
    PrintWriter printWriter = new PrintWriter(
    socketCliente.getOutputStream(), true);

    //mensaje petición cliente
    peticion = bufLeer.readLine();
    
    //Por si el navegador envía una petición vacía
    if (peticion == null) {
        return; 
    }

    //para compactar la petición y facilitar así su análisis, suprimimos todos 
    //los espacios en blanco que contenga
    peticion = peticion.replaceAll(" ", "");

    //si realmente se trata de una petición 'GET' (que es la única que vamos a
    //implementar en nuestro Servidor)
    if (peticion.startsWith("GET")) {
      //extrae la subcadena entre 'GET' y 'HTTP/1.1'
      peticion = peticion.substring(3, peticion.lastIndexOf("HTTP"));
      
      // Cabecera Date
      String fechaActual = DateTimeFormatter.RFC_1123_DATE_TIME.format(ZonedDateTime.now());
      String cabeceraDate = "Date: " + fechaActual;

      //si corresponde a la página de inicio
      if (peticion.length() == 0 || peticion.equals("/")) {
        //sirve la página
        html = Paginas.html_index;
        printWriter.println(Mensajes.lineaInicial_OK);
        printWriter.println(Paginas.primeraCabecera);       
        //Añadí aquí la cabecera Date
        printWriter.println(cabeceraDate);
        printWriter.println("Content-Length: " + (html.length() + 1));
        printWriter.println("\n");
        printWriter.println(html);
      } //si corresponde a la página del Quijote
      else if (peticion.equals("/quijote")) {
        //sirve la página
        html = Paginas.html_quijote;
        printWriter.println(Mensajes.lineaInicial_OK);
        printWriter.println(Paginas.primeraCabecera);
        //Aquí también la cabecera Date
        printWriter.println(cabeceraDate);
        printWriter.println("Content-Length: " + (html.length() + 1));
        printWriter.println("\n");
        printWriter.println(html);
      } //en cualquier otro caso
      else {
        //sirve la página
        html = Paginas.html_noEncontrado;
        printWriter.println(Mensajes.lineaInicial_NotFound);
        printWriter.println(Paginas.primeraCabecera);
        //Y aquí la misma cabecera Date
        printWriter.println(cabeceraDate);
        printWriter.println("Content-Length: " + (html.length() + 1));
        printWriter.println("\n");
        printWriter.println(html);
      }
    
    }
  }
  }