package psp06_tarea;

import java.io.*;
import java.util.logging.*;
import java.util.regex.*;

/**
 *
 * @author bobovino
 * 
 * Como estoy en Linux, en vez de c:/datos, voy a usar la ruta /home/bobovino/
 */

public class PSP06_Tarea {
    public static void main(String[] args) {
        // 1. Configurar el Logger 
        Logger logger = Logger.getLogger("AppLog");
        try {
            FileHandler fh = new FileHandler("/home/bobovino/datos/actividad.log", true); 
            logger.addHandler(fh);
            SimpleFormatter formatter = new SimpleFormatter(); 
            fh.setFormatter(formatter);
            logger.log(Level.INFO, "Aplicación iniciada."); // Nivel 5 
        } catch (IOException e) {
            System.out.println("Error al crear el log de actividad.");
        }

        //Abrimos buffer
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            // 2. Login del usuario
            System.out.println("Introduce el login (8 letras minúsculas):");
            String login = reader.readLine();
            Pattern patLogin = Pattern.compile("^[a-z]{8}$"); // Regex para 8 minúsculas
            Matcher matLogin = patLogin.matcher(login);

            //Si no pasa el filtro, informamos al usuario
            if (!matLogin.find()) { 
                System.out.println("Formato de login incorrecto.");
                logger.log(Level.WARNING, "Intento de login fallido."); // Nivel 6 
                return;
            }

            // 3.Pedimos el nombre del fichero 
            System.out.println("Introduce el nombre del fichero a mostrar:");
            String filename = reader.readLine();
            //Regex para Max 8 caracteres + 3 de extensión después del punto
            Pattern patFile = Pattern.compile("^[a-zA-Z0-9]{1,8}\\.[a-zA-Z0-9]{3}$");
            Matcher matFile = patFile.matcher(filename);

            if (!matFile.find()) {
                System.out.println("Formato de fichero incorrecto.");
                logger.log(Level.WARNING, "Formato de fichero incorrecto ingresado.");
                return;
            }

            // 4. Mostramos el contenido del fichero en pantalla si todo va bien
            File file = new File("/home/bobovino/datos/" + filename);
            //Netbeans ha convertido este bloque en un try with resources
            try (BufferedReader fileReader = new BufferedReader(new FileReader(file))) {
                String line;
                System.out.println("--- Contenido de " + filename + " ---");
                while ((line = fileReader.readLine()) != null) {
                    System.out.println(line);
                }
            }
            //Me ha dicho Netbeans que es mejor meter esta línea y las siguientes en una Lambda
            logger.log(Level.INFO, () -> "Fichero leído correctamente: " + filename);

        } catch (FileNotFoundException e) {
            logger.log(Level.SEVERE, () -> "El fichero no existe: " + e.getMessage()); // Nivel máximo 
        } catch (IOException e) { // Excepción de entrada/salida 
            logger.log(Level.SEVERE, () -> "Error de E/S durante la ejecución: " + e.getMessage());
        } catch (Exception e) { // Excepción general 
            logger.log(Level.SEVERE, () -> "Error inesperado: " + e.getMessage());
        }
    }
}
