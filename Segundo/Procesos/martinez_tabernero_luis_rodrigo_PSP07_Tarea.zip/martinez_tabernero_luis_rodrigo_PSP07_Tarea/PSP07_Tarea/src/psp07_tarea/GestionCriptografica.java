import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

public class GestionCriptografica {

    public static void main(String[] args) {
        String nombreFichero = "fichero.cifrado";
        String textoOriginal = "Este es el mensaje secreto que vamos a proteger.";
        
        // Datos para la semilla (también podríamos pedirlos por consola)
        String usuario = "Rodrigo";
        String password = "p@ssword2026";

        try {
            //Generamos la clave de 128 bits
            System.out.println("Generando clave...");
            SecretKey clave = generarClave(usuario + password, 128);

            // Ciframos y guardamos en fichero
            System.out.println("Cifrando texto...");
            encriptarFichero(textoOriginal, clave, nombreFichero);
            System.out.println("Fichero guardado como: " + nombreFichero);

            // Hacemos la inversa: Leemos y desencriptamos para probar
            System.out.println("\nLeyendo y desencriptando para verificación:");
            String textoDesencriptado = desencriptarFichero(clave, nombreFichero);
            System.out.println("Contenido recuperado: " + textoDesencriptado);

        } catch (Exception e) {
            System.err.println("Error en el proceso: " + e.getMessage());
        }
    }

    /**
     * Genera una clave AES a partir de una semilla (user + pass)
     */
    private static SecretKey generarClave(String semilla, int longitud) throws Exception {
        // Usamos el algoritmo SHA1PRNG para asegurar que la semilla sea la misma siempre
        SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
        sr.setSeed(semilla.getBytes(StandardCharsets.UTF_8));

        KeyGenerator kg = KeyGenerator.getInstance("AES");
        kg.init(longitud, sr);
        return kg.generateKey();
    }

    private static void encriptarFichero(String texto, SecretKey clave, String ruta) throws Exception {
        Cipher cifrador = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cifrador.init(Cipher.ENCRYPT_MODE, clave);

        byte[] bytesCifrados = cifrador.doFinal(texto.getBytes(StandardCharsets.UTF_8));

        try (FileOutputStream fos = new FileOutputStream(ruta)) {
            fos.write(bytesCifrados);
        }
    }

    private static String desencriptarFichero(SecretKey clave, String ruta) throws Exception {
        File archivo = new File(ruta);
        byte[] bytesLeidos = new byte[(int) archivo.length()];

        try (FileInputStream fis = new FileInputStream(archivo)) {
            fis.read(bytesLeidos);
        }

        Cipher descifrador = Cipher.getInstance("AES/ECB/PKCS5Padding");
        descifrador.init(Cipher.DECRYPT_MODE, clave);

        byte[] bytesClaro = descifrador.doFinal(bytesLeidos);
        return new String(bytesClaro, StandardCharsets.UTF_8);
    }
}