from odoo import models, fields

class Agenda(models.Model):
    _name = 'agenda.agenda'
    _description = 'Agenda Telefónica'

    name = fields.Char(string='Nombre', required=True)
    telefono = fields.Char(string='Teléfono', required=True)