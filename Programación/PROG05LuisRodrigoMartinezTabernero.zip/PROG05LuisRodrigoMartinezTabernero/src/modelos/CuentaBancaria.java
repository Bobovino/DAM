package modelos;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

//Esta clase no tiene mucha complicación, es una clase con su constructor, 
// getters y setters que te crea Netbeans.

public class CuentaBancaria {
    private static int semillaNumeroCuenta = 10000;
    private int numeroCuenta;
    private Cliente cliente;
    private LocalDate fechaApertura;
    private double saldo;

    public CuentaBancaria(Cliente cliente, double saldoInicial) {
        this.numeroCuenta = semillaNumeroCuenta++;
        setCliente(cliente);
        setSaldo(saldoInicial);
        setFechaApertura();
    }

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        if (cliente == null) {
            throw new IllegalArgumentException("Cliente inválido");
        }
        this.cliente = cliente;
    }

    public String getFechaApertura() {
        return fechaApertura.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    private void setFechaApertura() {
        this.fechaApertura = LocalDate.now();
    }

    public double getSaldo() {
        return saldo;
    }

    private void setSaldo(double saldoInicial) {
        if (saldoInicial <= 0) {
            throw new IllegalArgumentException("Saldo inicial debe ser mayor que cero");
        }
        this.saldo = saldoInicial;
    }

    public void ingresar(double cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("Cantidad a ingresar inválida");
        }
        this.saldo += cantidad;
    }

    public void reintegrar(double cantidad) {
        if (cantidad <= 0 || (this.saldo - cantidad) < 0) {
            throw new IllegalArgumentException("Reintegro inválido");
        }
        this.saldo -= cantidad;
    }
}
