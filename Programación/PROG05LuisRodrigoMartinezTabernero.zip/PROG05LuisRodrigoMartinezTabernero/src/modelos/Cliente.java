package modelos;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Cliente {
    private String nombre;
    private String dni;
    private LocalDate fechaNacimiento;

    public Cliente(String nombre, String dni, String fechaNacimiento) {
        setNombre(nombre);
        setDni(dni);
        setFechaNacimiento(fechaNacimiento);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        // Comprobamos que el nombre no sea nulo o vacío. La función trim elimina los
        // espacios en blanco.
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("Nombre vacío");
        }
        this.nombre = nombre;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        // Validación del DNI con una expresión regular que he sacado de Google, no le
        // voy a mentir
        if (dni == null || !dni.matches("\\d{7,8}[A-Za-z]")) {
            throw new IllegalArgumentException("DNI inválido");
        }
        this.dni = dni;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fecha) {
        try {
            // Día/Mes/Año
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fnac = LocalDate.parse(fecha, formatter);
            // Comprobamos que el cliente sea mayor de edad comparandolo con la fecha
            // actual.
            // Devuelve un valor booleano la comparación de dos fechas.
            if (fnac.plusYears(18).isAfter(LocalDate.now())) {
                throw new IllegalArgumentException("El cliente debe ser mayor de edad");
            }
            this.fechaNacimiento = fnac;
        } catch (Exception e) {
            throw new IllegalArgumentException("Fecha de nacimiento inválida");
        }
    }

    public int getEdad() {
        // ChronoUnit es una clase que nos permite calcular la diferencia entre dos
        // fechas, la actual y la fecha de nacimiento. Devuelve un valor numérico de
        // tipo long.
        return (int) ChronoUnit.YEARS.between(fechaNacimiento, LocalDate.now());
    }
}
