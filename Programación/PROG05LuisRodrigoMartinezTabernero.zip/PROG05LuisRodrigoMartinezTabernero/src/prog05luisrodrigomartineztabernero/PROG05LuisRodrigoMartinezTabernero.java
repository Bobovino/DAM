package prog05luisrodrigomartineztabernero;

import modelos.Cliente;
import modelos.CuentaBancaria;
import java.util.Scanner;
import java.text.DecimalFormat;

/**
 *
 * @author bobovino
 */

// Bobovino es mi nickname, por cierto

public class PROG05LuisRodrigoMartinezTabernero {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CuentaBancaria cuenta = null;
        int opcion;

        // He hecho el menú como un switch/case dentro de un do/while para que corra una
        // vez mínimo, y hasta que se presione 6
        do {
            System.out.println("Gestión de cuenta bancaria");
            System.out.println("1. Crear cuenta bancaria.");
            System.out.println("2. Mostrar datos de la cuenta.");
            System.out.println("3. Realizar ingreso.");
            System.out.println("4. Realizar reintegro.");
            System.out.println("5. Mostrar la edad del cliente.");
            System.out.println("6. Salir.");
            System.out.print("Elige una opción: ");
            try {
                opcion = Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                System.out.println("Error al leer la opción: " + e.getMessage());
                opcion = -1;
            }

            switch (opcion) {
                case 1:
                    cuenta = crearCuenta(sc);
                    break;
                case 2:
                    if (cuenta != null)
                        mostrarDatos(cuenta);
                    else
                        System.out.println("No existe cuenta creada.");
                    break;
                case 3:
                    if (cuenta != null)
                        realizarIngreso(cuenta, sc);
                    else
                        System.out.println("No existe cuenta creada.");
                    break;
                case 4:
                    if (cuenta != null)
                        realizarReintegro(cuenta, sc);
                    else
                        System.out.println("No existe cuenta creada.");
                    break;
                case 5:
                    if (cuenta != null) {
                        System.out.println("Edad del cliente: " + cuenta.getCliente().getEdad() + " años.");
                    } else {
                        System.out.println("No existe cuenta creada.");
                    }
                    break;
                case 6:
                    System.out.println("Aplicación finalizada");
                    break;
                default:
                    System.out.println("Opción inválida");
            }
            System.out.println();
        } while (opcion != 6);
    }

    // Creamos instancia de objeto cliente y con la clase scanner introducimos los
    // datos.

    private static CuentaBancaria crearCuenta(Scanner sc) {
        System.out.println("Crear cuenta bancaria");
        try {
            System.out.print("Nombre del cliente: ");
            String nombre = sc.nextLine();
            System.out.print("DNI del cliente: ");
            String dni = sc.nextLine();
            System.out.print("Fecha de nacimiento (dd/MM/yyyy): ");
            String fechaNac = sc.nextLine();
            System.out.print("Saldo inicial de la cuenta: ");
            double saldoInicial = Double.parseDouble(sc.nextLine());

            Cliente cli = new Cliente(nombre, dni, fechaNac);
            return new CuentaBancaria(cli, saldoInicial);
        } catch (Exception e) {
            System.out.println("Error al crear cuenta: " + e.getMessage());
            return null;
        }
    }

    // Es un método void porque no devuelve nada. Estático para no necesitar crear
    // una instancia.
    private static void mostrarDatos(CuentaBancaria cuenta) {
        // Para conseguir el formato que queremos, usamos la subclase de NumberFormat()
        // que nos permite el formato dd/mm/aaaa o dd/mm/yyyy
        DecimalFormat df = new DecimalFormat("#0.00");
        System.out.println("Mostrar datos cuenta bancaria");
        System.out.println("Número de cuenta bancaria: " + cuenta.getNumeroCuenta());
        System.out.println("Nombre del cliente: " + cuenta.getCliente().getNombre());
        System.out.println("DNI del cliente: " + cuenta.getCliente().getDni());
        System.out.println("Fecha de nacimiento: " +
                String.format("%02d/%02d/%04d",
                        cuenta.getCliente().getFechaNacimiento().getDayOfMonth(),
                        cuenta.getCliente().getFechaNacimiento().getMonthValue(),
                        cuenta.getCliente().getFechaNacimiento().getYear()));
        System.out.println("Fecha de apertura de la cuenta: " + cuenta.getFechaApertura());
        System.out.println("Saldo inicial de la cuenta: " + df.format(cuenta.getSaldo()) + " €");
    }

    // Al realizar reintegro e ingreso no tenemos que devolver nada, solo llamar a
    // los métodos de la clase y mostrar por pantalla el resultado
    private static void realizarIngreso(CuentaBancaria cuenta, Scanner sc) {
        System.out.println("Realizar ingreso");
        try {
            System.out.print("Cantidad: ");
            double cantidad = Double.parseDouble(sc.nextLine());
            cuenta.ingresar(cantidad);
            System.out.println("Saldo actual: " + formatearSaldo(cuenta.getSaldo()));
        } catch (Exception e) {
            System.out.println("Error al ingresar: " + e.getMessage());
        }
    }

    private static void realizarReintegro(CuentaBancaria cuenta, Scanner sc) {
        System.out.println("Realizar reintegro");
        try {
            System.out.print("Cantidad: ");
            double cantidad = Double.parseDouble(sc.nextLine());
            cuenta.reintegrar(cantidad);
            System.out.println("Saldo actual: " + formatearSaldo(cuenta.getSaldo()));
        } catch (Exception e) {
            System.out.println("Error al reintegrar: " + e.getMessage());
        }
    }

    // Método auxiliar porque esto no funcionaba tal cual con double y ha habido que
    // convertir
    // el saldo a String
    private static String formatearSaldo(double saldo) {
        DecimalFormat df = new DecimalFormat("#0.00");
        return df.format(saldo) + " €";
    }

}
