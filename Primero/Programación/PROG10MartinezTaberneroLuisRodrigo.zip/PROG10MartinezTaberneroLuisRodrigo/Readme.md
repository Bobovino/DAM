# Ir a donde tengamos el proyecto

cd /home/bobovino/NetBeansProjects/PROG10MartinezTaberneroLuisRodrigo

# Compilar(cambiar el path al javafx-sdk que tengamos instalado)

IMPORTANTE: TIENEN QUE SER COMPATIBLES EL SO, la versión de java --version y la versión de javaFX-sdk

javac --module-path /home/bobovino/Downloads/javafx-sdk-24/lib --add-modules javafx.controls -d build/classes src/modelos/_.java src/prog10martineztaberneroluisrodrigo/_.java

# Copiar la hoja de estilos

cp src/prog10martineztaberneroluisrodrigo/estilos.css build/classes/prog10martineztaberneroluisrodrigo/

# Correr la aplicación

java --module-path /home/bobovino/Downloads/javafx-sdk-24/lib --add-modules javafx.controls --enable-native-access=javafx.graphics -cp build/classes prog10martineztaberneroluisrodrigo.PROG10_FX
