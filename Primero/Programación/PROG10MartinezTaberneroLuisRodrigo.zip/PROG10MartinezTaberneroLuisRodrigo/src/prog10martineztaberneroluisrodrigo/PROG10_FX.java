package prog10martineztaberneroluisrodrigo;

import java.text.DecimalFormat;
import java.util.Optional;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import modelos.Concesionario;
import modelos.Vehiculo;

/**
 * Clase principal de la aplicación JavaFX para gestión de concesionario
 * 
 * @author bobovino (Luis Rodrigo Martínez Tabernero)
 */
public class PROG10_FX extends Application {

    private Concesionario concesionario;
    private static final DecimalFormat formatoPrecio = new DecimalFormat("#,##0.00 €");

    @Override
    public void start(Stage primaryStage) {
        concesionario = new Concesionario();

        // Crear el contenedor principal como un GridPane
        GridPane menuGrid = new GridPane();
        menuGrid.setAlignment(Pos.CENTER);
        menuGrid.setHgap(20); // Espaciado horizontal entre columnas
        menuGrid.setVgap(20); // Espaciado vertical entre filas
        menuGrid.setPadding(new Insets(20)); // Espaciado alrededor del GridPane

        // Crear el título
        Label titulo = new Label("GESTIÓN DE VEHÍCULOS DE UN CONCESIONARIO");
        titulo.getStyleClass().add("titulo");

        // Crear botones con estilo uniforme
        Button btnNuevo = crearBotonMenu("Nuevo Vehículo");
        Button btnListar = crearBotonMenu("Listar Vehículos");
        Button btnBuscar = crearBotonMenu("Buscar Vehículo");
        Button btnModificar = crearBotonMenu("Modificar Kilómetros");
        Button btnSalir = crearBotonMenu("Salir");

        // Añadir acciones a los botones
        btnNuevo.setOnAction(e -> mostrarFormularioNuevoVehiculo(primaryStage));
        btnListar.setOnAction(e -> mostrarListadoVehiculos(primaryStage));
        btnBuscar.setOnAction(e -> mostrarFormularioBusqueda(primaryStage));
        btnModificar.setOnAction(e -> mostrarFormularioModificarKilometros(primaryStage));
        btnSalir.setOnAction(e -> primaryStage.close());

        // Añadir los botones al GridPane (3 columnas)
        menuGrid.add(btnNuevo, 0, 0); // Columna 0, Fila 0
        menuGrid.add(btnListar, 1, 0); // Columna 1, Fila 0
        menuGrid.add(btnBuscar, 2, 0); // Columna 2, Fila 0
        menuGrid.add(btnModificar, 0, 1); // Columna 0, Fila 1
        menuGrid.add(btnSalir, 1, 1); // Columna 1, Fila 1

        // Crear un contenedor principal para el título y el GridPane
        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.getChildren().addAll(titulo, menuGrid);

        // Configurar la escena y mostrar
        Scene scene = new Scene(root, 600, 400);

        // Importar la hoja de estilos
        scene.getStylesheets().add(getClass().getResource("estilos.css").toExternalForm());

        primaryStage.setTitle("Concesionario de Vehículos");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Crea un botón de menú principal con estilo uniforme
     * 
     * @param texto Texto del botón
     * @return Botón estilizado para el menú
     */
    private Button crearBotonMenu(String texto) {
        Button btn = new Button(texto);
        btn.getStyleClass().add("boton-menu");

        // Hacer que el botón sea cuadrado
        btn.setPrefSize(120, 120); // Tamaño preferido (ancho y alto iguales)
        return btn;
    }

    /**
     * Muestra el formulario para añadir un nuevo vehículo
     * 
     * @param owner Ventana propietaria
     */
    private void mostrarFormularioNuevoVehiculo(Stage owner) {
        // Crear ventana modal
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(owner);
        dialog.setTitle("Nuevo Vehículo");

        // Crear componentes del formulario
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);

        // Campos del formulario
        TextField txtMarca = new TextField();
        TextField txtMatricula = new TextField();
        TextField txtKilometros = new TextField();
        TextField txtFechaMatriculacion = new TextField();
        TextField txtDescripcion = new TextField();
        TextField txtPrecio = new TextField();

        // Etiquetas
        grid.add(new Label("Marca:"), 0, 0);
        grid.add(txtMarca, 1, 0);
        grid.add(new Label("Matrícula (NNNNLLL):"), 0, 1);
        grid.add(txtMatricula, 1, 1);
        grid.add(new Label("Kilómetros:"), 0, 2);
        grid.add(txtKilometros, 1, 2);
        grid.add(new Label("Fecha Matriculación (dd/MM/yyyy):"), 0, 3);
        grid.add(txtFechaMatriculacion, 1, 3);
        grid.add(new Label("Descripción:"), 0, 4);
        grid.add(txtDescripcion, 1, 4);
        grid.add(new Label("Precio:"), 0, 5);
        grid.add(txtPrecio, 1, 5);

        // Botones
        Button btnGuardar = new Button("Guardar");
        Button btnCancelar = new Button("Cancelar");

        HBox botonesBox = new HBox(10);
        botonesBox.getChildren().addAll(btnGuardar, btnCancelar);
        botonesBox.setAlignment(Pos.CENTER_RIGHT);
        grid.add(botonesBox, 1, 6);

        // Acciones de botones
        btnGuardar.setOnAction(e -> {
            try {
                String marca = txtMarca.getText();
                String matricula = txtMatricula.getText();
                int kilometros = Integer.parseInt(txtKilometros.getText());
                String fechaMatriculacion = txtFechaMatriculacion.getText();
                String descripcion = txtDescripcion.getText();
                double precio = Double.parseDouble(txtPrecio.getText());

                Vehiculo vehiculo = new Vehiculo(marca, matricula, kilometros,
                        fechaMatriculacion, descripcion, precio);
                concesionario.nuevoVehiculo(vehiculo);

                mostrarMensaje(Alert.AlertType.INFORMATION, "Vehículo añadido",
                        "El vehículo ha sido añadido correctamente.");
                dialog.close();
            } catch (NumberFormatException ex) {
                mostrarMensaje(Alert.AlertType.ERROR, "Error",
                        "Los campos numéricos deben contener números válidos.");
            } catch (IllegalArgumentException ex) {
                mostrarMensaje(Alert.AlertType.ERROR, "Error", ex.getMessage());
            }
        });

        btnCancelar.setOnAction(e -> dialog.close());

        // Mostrar dialog
        Scene scene = new Scene(grid, 500, 300);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    /**
     * Muestra el listado de vehículos en una tabla
     * 
     * @param owner Ventana propietaria
     */
    private void mostrarListadoVehiculos(Stage owner) {
        // Crear ventana modal
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(owner);
        dialog.setTitle("Listado de Vehículos");

        // Tabla para mostrar los vehículos
        TableView<Vehiculo> tabla = new TableView<>();

        // Definir columnas
        TableColumn<Vehiculo, String> colMarca = new TableColumn<>("Marca");
        colMarca.setCellValueFactory(new PropertyValueFactory<>("marca"));

        TableColumn<Vehiculo, String> colMatricula = new TableColumn<>("Matrícula");
        colMatricula.setCellValueFactory(new PropertyValueFactory<>("matricula"));

        TableColumn<Vehiculo, Integer> colKilometros = new TableColumn<>("Kilómetros");
        colKilometros.setCellValueFactory(new PropertyValueFactory<>("kilometros"));

        TableColumn<Vehiculo, String> colFecha = new TableColumn<>("Fecha Matriculación");
        colFecha.setCellValueFactory(data -> javafx.beans.binding.Bindings.createStringBinding(
                () -> data.getValue().getFechaMatriculacionFormateada()));

        TableColumn<Vehiculo, Integer> colAntiguedad = new TableColumn<>("Años");
        colAntiguedad.setCellValueFactory(new PropertyValueFactory<>("antiguedad"));

        TableColumn<Vehiculo, Double> colPrecio = new TableColumn<>("Precio");
        colPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));
        colPrecio.setCellFactory(tc -> new TableCell<Vehiculo, Double>() {
            @Override
            protected void updateItem(Double precio, boolean empty) {
                super.updateItem(precio, empty);
                if (empty || precio == null) {
                    setText(null);
                } else {
                    setText(formatoPrecio.format(precio));
                }
            }
        });

        TableColumn<Vehiculo, String> colDescripcion = new TableColumn<>("Descripción");
        colDescripcion.setCellValueFactory(new PropertyValueFactory<>("descripcion"));

        // Añadir columnas a la tabla
        tabla.getColumns().addAll(colMarca, colMatricula, colPrecio, colKilometros,
                colFecha, colAntiguedad, colDescripcion);

        // Añadir datos
        Vehiculo[] vehiculos = concesionario.getVehiculos();
        for (Vehiculo v : vehiculos) {
            tabla.getItems().add(v);
        }

        // Configurar layout
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        Label titulo = new Label("Listado de Vehículos");
        titulo.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Button btnCerrar = new Button("Cerrar");
        btnCerrar.setOnAction(e -> dialog.close());

        root.getChildren().addAll(titulo, tabla, btnCerrar);

        // Mostrar ventana
        Scene scene = new Scene(root, 800, 500);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    /**
     * Muestra el formulario para buscar un vehículo
     * 
     * @param owner Ventana propietaria
     */
    private void mostrarFormularioBusqueda(Stage owner) {
        // Crear ventana modal
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(owner);
        dialog.setTitle("Buscar Vehículo");

        // Layout
        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label titulo = new Label("Buscar Vehículo por Matrícula");
        titulo.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        HBox busquedaBox = new HBox(10);
        busquedaBox.setAlignment(Pos.CENTER);
        Label lblMatricula = new Label("Matrícula:");
        TextField txtMatricula = new TextField();
        Button btnBuscar = new Button("Buscar");
        busquedaBox.getChildren().addAll(lblMatricula, txtMatricula, btnBuscar);

        // Área para mostrar resultados
        VBox resultadoBox = new VBox(10);
        resultadoBox.setAlignment(Pos.CENTER_LEFT);
        resultadoBox.setVisible(false);

        Label lblResultado = new Label("Vehículo encontrado:");
        lblResultado.setStyle("-fx-font-weight: bold;");

        GridPane datosGrid = new GridPane();
        datosGrid.setHgap(10);
        datosGrid.setVgap(10);

        Label lblMarca = new Label("Marca:");
        Label lblMarcaValor = new Label();
        datosGrid.add(lblMarca, 0, 0);
        datosGrid.add(lblMarcaValor, 1, 0);

        Label lblMatriculaRes = new Label("Matrícula:");
        Label lblMatriculaValor = new Label();
        datosGrid.add(lblMatriculaRes, 0, 1);
        datosGrid.add(lblMatriculaValor, 1, 1);

        Label lblAntiguedad = new Label("Años:");
        Label lblAntiguedadValor = new Label();
        datosGrid.add(lblAntiguedad, 0, 2);
        datosGrid.add(lblAntiguedadValor, 1, 2);

        Label lblPrecio = new Label("Precio:");
        Label lblPrecioValor = new Label();
        datosGrid.add(lblPrecio, 0, 3);
        datosGrid.add(lblPrecioValor, 1, 3);

        resultadoBox.getChildren().addAll(lblResultado, datosGrid);

        Button btnCerrar = new Button("Cerrar");
        btnCerrar.setOnAction(e -> dialog.close());

        root.getChildren().addAll(titulo, busquedaBox, resultadoBox, btnCerrar);

        // Acción del botón buscar
        btnBuscar.setOnAction(e -> {
            String matricula = txtMatricula.getText();
            Vehiculo vehiculo = concesionario.buscarVehiculo(matricula);

            if (vehiculo != null) {
                lblMarcaValor.setText(vehiculo.getMarca());
                lblMatriculaValor.setText(vehiculo.getMatricula());
                lblAntiguedadValor.setText(String.valueOf(vehiculo.getAntiguedad()));
                lblPrecioValor.setText(formatoPrecio.format(vehiculo.getPrecio()));
                resultadoBox.setVisible(true);
            } else {
                mostrarMensaje(Alert.AlertType.INFORMATION, "Búsqueda",
                        "No se ha encontrado ningún vehículo con matrícula " + matricula);
                resultadoBox.setVisible(false);
            }
        });

        // Mostrar ventana
        Scene scene = new Scene(root, 500, 400);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    /**
     * Muestra el formulario para modificar kilómetros
     * 
     * @param owner Ventana propietaria
     */
    private void mostrarFormularioModificarKilometros(Stage owner) {
        // Crear ventana modal
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(owner);
        dialog.setTitle("Modificar Kilómetros");

        // Layout
        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label titulo = new Label("Modificar Kilómetros de un Vehículo");
        titulo.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);

        Label lblMatricula = new Label("Matrícula:");
        TextField txtMatricula = new TextField();
        grid.add(lblMatricula, 0, 0);
        grid.add(txtMatricula, 1, 0);

        Label lblKilometros = new Label("Kilómetros a añadir:");
        TextField txtKilometros = new TextField();
        grid.add(lblKilometros, 0, 1);
        grid.add(txtKilometros, 1, 1);

        HBox botonesBox = new HBox(10);
        botonesBox.setAlignment(Pos.CENTER);
        Button btnActualizar = new Button("Actualizar");
        Button btnCancelar = new Button("Cancelar");
        botonesBox.getChildren().addAll(btnActualizar, btnCancelar);

        root.getChildren().addAll(titulo, grid, botonesBox);

        // Acciones de botones
        btnActualizar.setOnAction(e -> {
            try {
                String matricula = txtMatricula.getText();
                int kilometros = Integer.parseInt(txtKilometros.getText());

                concesionario.modificarKilometros(matricula, kilometros);
                mostrarMensaje(Alert.AlertType.INFORMATION, "Kilómetros actualizados",
                        "Los kilómetros han sido actualizados correctamente.");
                dialog.close();
            } catch (NumberFormatException ex) {
                mostrarMensaje(Alert.AlertType.ERROR, "Error",
                        "El valor de kilómetros debe ser un número entero.");
            } catch (IllegalArgumentException ex) {
                mostrarMensaje(Alert.AlertType.ERROR, "Error", ex.getMessage());
            }
        });

        btnCancelar.setOnAction(e -> dialog.close());

        // Mostrar ventana
        Scene scene = new Scene(root, 400, 250);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    /**
     * Muestra un mensaje de alerta
     * 
     * @param tipo    Tipo de alerta
     * @param titulo  Título del mensaje
     * @param mensaje Contenido del mensaje
     */
    private void mostrarMensaje(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
