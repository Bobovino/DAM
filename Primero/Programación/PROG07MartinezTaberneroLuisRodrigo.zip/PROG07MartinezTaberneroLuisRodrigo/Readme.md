# Para generar docs

javadoc -d docs -sourcepath src -subpackages prog07martineztaberneroluisrodrigo

# Para abrir los docs generados

xdg-open docs/index.html
