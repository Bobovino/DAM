package prog07martineztaberneroluisrodrigo;

import java.util.Scanner;
import modelos.Localidad;
import modelos.Lugar;
import modelos.PDI;
import modelos.PuntoGeografico;
import modelos.Lugar.TipoLugar;

/**
 * Sistema de Información Geográfica (SIG) para la gestión de PDIs.
 * Permite crear, visualizar y eliminar PDIs(Puntos de informacion) y calcular distancias.
 * Un PDI es un punto geografico con unas coordenadas y otra informacion como un nombre, descripcion...
 * 
 * @author bobovino
 */
public class PROG07MartinezTaberneroLuisRodrigo {

    // Arrays para almacenar PDIs
    private static Localidad[] localidades = new Localidad[100];
    private static Lugar[] lugares = new Lugar[500];

    // Contadores
    private static int numLocalidades = 0;
    private static int numLugares = 0;

    // Scanner para entrada
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Hacemos el tipico menu de consola consistente en un switch dentro de un bucle do while.
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            try {
                switch (opcion) {
                    case 1:
                        crearLocalidad();
                        break;
                    case 2:
                        crearLugar();
                        break;
                    case 3:
                        visualizarLocalidades();
                        break;
                    case 4:
                        visualizarLugares();
                        break;
                    case 5:
                        eliminarLocalidad();
                        break;
                    case 6:
                        eliminarLugar();
                        break;
                    case 7:
                        calcularDistanciaEntrePDIs();
                        break;
                    case 0:
                        System.out.println("Saliendo del programa...");
                        break;
                    default:
                        System.out.println("Opción no válida. Intente de nuevo.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (opcion != 0);
        scanner.close();
    }

    private static void mostrarMenu() {
        System.out.println("\n===== MENÚ SIG =====");
        System.out.println("1. Crear Localidad");
        System.out.println("2. Crear Lugar");
        System.out.println("3. Mostrar Localidades");
        System.out.println("4. Mostrar Lugares");
        System.out.println("5. Eliminar Localidad");
        System.out.println("6. Eliminar Lugar");
        System.out.println("7. Calcular distancia entre dos PDIs");
        System.out.println("0. Salir");
    }

    private static void crearLocalidad() {
        if (numLocalidades >= localidades.length) {
            System.out.println("Se ha alcanzado el máximo de localidades.");
            return;
        }
        System.out.println("\n--- Crear Localidad ---");
        String nombre = leerString("Nombre: ");
        PuntoGeografico punto = crearPuntoGeografico();
        double valoracion = leerDouble("Valoración (0 a 5): ");
        double extension = leerDouble("Extensión (km²): ");
        int habitantes = leerEntero("Número de habitantes: ");
        try {
            Localidad loc = new Localidad(nombre, punto, valoracion, extension, habitantes);
            localidades[numLocalidades++] = loc;
            System.out.println("Localidad creada correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error al crear la localidad: " + e.getMessage());
        }
    }

    private static void crearLugar() {
        if (numLugares >= lugares.length) {
            System.out.println("Se ha alcanzado el máximo de lugares.");
            return;
        }
        System.out.println("\n--- Crear Lugar ---");
        String nombre = leerString("Nombre: ");
        PuntoGeografico punto = crearPuntoGeografico();
        double valoracion = leerDouble("Valoración (0 a 5): ");
        String descripcion = leerString("Descripción: ");
        TipoLugar tipo = seleccionarTipoLugar();
        try {
            Lugar lugar = new Lugar(nombre, punto, valoracion, descripcion, tipo);
            lugares[numLugares++] = lugar;
            System.out.println("Lugar creado correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error al crear el lugar: " + e.getMessage());
        }
    }

    private static PuntoGeografico crearPuntoGeografico() {
        System.out.println("\n--- Crear Punto Geográfico ---");
        double longitud = 0, latitud = 0, altura = 0;
        boolean valido = false;
        while (!valido) {
            try {
                longitud = leerDouble("Longitud (-180 a 180): ");
                if (longitud < -180 || longitud > 180)
                    throw new IllegalArgumentException("Longitud fuera de rango");
                valido = true;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        valido = false;
        while (!valido) {
            try {
                latitud = leerDouble("Latitud (-90 a 90): ");
                if (latitud < -90 || latitud > 90)
                    throw new IllegalArgumentException("Latitud fuera de rango");
                valido = true;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        valido = false;
        while (!valido) {
            try {
                altura = leerDouble("Altura (mayor que 0): ");
                if (altura <= 0)
                    throw new IllegalArgumentException("La altura debe ser mayor que 0");
                valido = true;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        return new PuntoGeografico(longitud, latitud, altura);
    }

    private static TipoLugar seleccionarTipoLugar() {
        System.out.println("Tipos de Lugar:");
        System.out.println("1. RESTAURANTE");
        System.out.println("2. CAFETERIA");
        System.out.println("3. HOTEL");
        System.out.println("4. MONUMENTO");
        System.out.println("5. MUSEO");
        int op;
        do {
            op = leerEntero("Seleccione un tipo (1-5): ");
        } while (op < 1 || op > 5);
        switch (op) {
            case 1:
                return TipoLugar.RESTAURANTE;
            case 2:
                return TipoLugar.CAFETERIA;
            case 3:
                return TipoLugar.HOTEL;
            case 4:
                return TipoLugar.MONUMENTO;
            case 5:
                return TipoLugar.MUSEO;
            default:
                return TipoLugar.RESTAURANTE;
        }
    }

    private static void visualizarLocalidades() {
        System.out.println("\n--- Localidades Registradas ---");
        if (numLocalidades == 0) {
            System.out.println("No hay localidades registradas.");
            return;
        }
        for (int i = 0; i < numLocalidades; i++) {
            System.out.println("Localidad #" + (i + 1));
            localidades[i].visualizar();
        }
    }

    private static void visualizarLugares() {
        System.out.println("\n--- Lugares Registrados ---");
        if (numLugares == 0) {
            System.out.println("No hay lugares registrados.");
            return;
        }
        for (int i = 0; i < numLugares; i++) {
            System.out.println("Lugar #" + (i + 1));
            lugares[i].visualizar();
        }
    }

    private static void eliminarLocalidad() {
        if (numLocalidades == 0) {
            System.out.println("No existen localidades a eliminar.");
            return;
        }
        System.out.println("\n--- Eliminar Localidad ---");
        for (int i = 0; i < numLocalidades; i++) {
            System.out.println((i + 1) + ". " + localidades[i].getNombre());
        }
        int indice = leerEntero("Seleccione el número de la localidad a eliminar: ");
        if (indice < 1 || indice > numLocalidades) {
            System.out.println("Índice no válido");
            return;
        }
        for (int i = indice - 1; i < numLocalidades - 1; i++) {
            localidades[i] = localidades[i + 1];
        }
        localidades[--numLocalidades] = null;
        System.out.println("Localidad eliminada.");
    }

    private static void eliminarLugar() {
        if (numLugares == 0) {
            System.out.println("No existen lugares a eliminar.");
            return;
        }
        System.out.println("\n--- Eliminar Lugar ---");
        for (int i = 0; i < numLugares; i++) {
            System.out.println((i + 1) + ". " + lugares[i].getNombre());
        }
        int indice = leerEntero("Seleccione el número del lugar a eliminar: ");
        if (indice < 1 || indice > numLugares) {
            System.out.println("Índice no válido");
            return;
        }
        for (int i = indice - 1; i < numLugares - 1; i++) {
            lugares[i] = lugares[i + 1];
        }
        lugares[--numLugares] = null;
        System.out.println("Lugar eliminado.");
    }

    private static void calcularDistanciaEntrePDIs() {
        if (numLocalidades + numLugares < 2) {
            System.out.println("No hay suficientes PDIs para calcular la distancia.");
            return;
        }
        System.out.println("\n--- Calcular Distancia Entre PDIs ---");
        // Para simplificar, se listan todos los PDIs (localidades seguidas de lugares)
        int total = numLocalidades + numLugares;
        PDI[] pdIs = new PDI[total];
        for (int i = 0; i < numLocalidades; i++) {
            pdIs[i] = localidades[i];
        }
        for (int i = 0; i < numLugares; i++) {
            pdIs[numLocalidades + i] = lugares[i];
        }
        for (int i = 0; i < total; i++) {
            System.out.println((i + 1) + ". " + pdIs[i].getNombre());
        }
        int idx1 = leerEntero("Seleccione el primer PDI: ");
        int idx2 = leerEntero("Seleccione el segundo PDI: ");
        if (idx1 < 1 || idx1 > total || idx2 < 1 || idx2 > total) {
            System.out.println("Índices no válidos.");
            return;
        }
        double distancia = pdIs[idx1 - 1].calcularDistancia(pdIs[idx2 - 1]);
        System.out.println("La distancia entre \"" + pdIs[idx1 - 1].getNombre() + "\" y \"" +
                pdIs[idx2 - 1].getNombre() + "\" es: " + distancia + " km.");
    }

    // Métodos de apoyo para lectura
    private static int leerEntero(String mensaje) {
        System.out.print(mensaje);
        while (!scanner.hasNextInt()) {
            scanner.next();
            System.out.print("Entrada inválida. " + mensaje);
        }
        return scanner.nextInt();
    }

    private static double leerDouble(String mensaje) {
        System.out.print(mensaje);
        while (!scanner.hasNextDouble()) {
            scanner.next();
            System.out.print("Entrada inválida. " + mensaje);
        }
        return scanner.nextDouble();
    }

    private static String leerString(String mensaje) {
        System.out.print(mensaje);
        return scanner.next();
    }
}
