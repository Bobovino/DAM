package modelos;

/**
 * Clase que representa un lugar (restaurante, hotel, monumento, etc.) como PDI.
 */
public class Lugar extends PDI {

    /**
     * Enumeración que define los tipos de lugares disponibles.
     */
    public enum TipoLugar {
        RESTAURANTE, CAFETERIA, HOTEL, MONUMENTO, MUSEO
    }

    private String descripcion;
    private TipoLugar tipo;

    /**
     * Constructor para crear un lugar.
     * 
     * @param nombre       Nombre del lugar.
     * @param localizacion Punto geográfico donde se encuentra el lugar.
     * @param valoracion   Valoración del lugar (de 0 a 5).
     * @param descripcion  Descripción del lugar.
     * @param tipo         Tipo de lugar.
     * @throws IllegalArgumentException Si los valores no son válidos.
     */
    public Lugar(String nombre, PuntoGeografico localizacion, double valoracion,
            String descripcion, TipoLugar tipo) {
        super(nombre, localizacion, valoracion);
        setDescripcion(descripcion);
        setTipo(tipo);
    }

    /**
     * Establece la descripción del lugar.
     * 
     * @param descripcion Descripción del lugar.
     * @throws IllegalArgumentException Si la descripción está vacía o es nula.
     */
    public void setDescripcion(String descripcion) {
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripción no puede estar vacía");
        }
        this.descripcion = descripcion;
    }

    /**
     * Establece el tipo de lugar.
     * 
     * @param tipo Tipo de lugar.
     * @throws IllegalArgumentException Si el tipo es nulo.
     */
    public void setTipo(TipoLugar tipo) {
        if (tipo == null) {
            throw new IllegalArgumentException("El tipo de lugar no puede ser nulo");
        }
        this.tipo = tipo;
    }

    /**
     * Obtiene la descripción del lugar.
     * 
     * @return La descripción del lugar.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Obtiene el tipo de lugar.
     * 
     * @return El tipo de lugar.
     */
    public TipoLugar getTipo() {
        return tipo;
    }

    @Override
    public void visualizar() {
        super.visualizar();
        System.out.println("Tipo: " + tipo);
        System.out.println("Descripción: " + descripcion);
        System.out.println("----------------------------------------");
    }
}