package modelos;

/**
 * Clase que representa una localidad (ciudad, pueblo, etc.) como PDI.
 */
public class Localidad extends PDI {
    private double extension; // En kilómetros cuadrados
    private int habitantes; // Número de habitantes

    /**
     * Constructor para crear una localidad.
     * 
     * @param nombre       Nombre de la localidad.
     * @param localizacion Punto geográfico donde se encuentra la localidad.
     * @param valoracion   Valoración de la localidad (de 0 a 5).
     * @param extension    Extensión de la localidad en km².
     * @param habitantes   Número de habitantes de la localidad.
     * @throws IllegalArgumentException Si los valores no son válidos.
     */
    public Localidad(String nombre, PuntoGeografico localizacion, double valoracion,
            double extension, int habitantes) {
        super(nombre, localizacion, valoracion);
        setExtension(extension);
        setHabitantes(habitantes);
    }

    /**
     * Establece la extensión de la localidad.
     * 
     * @param extension Extensión en km².
     * @throws IllegalArgumentException Si la extensión es negativa o cero.
     */
    public void setExtension(double extension) {
        if (extension <= 0) {
            throw new IllegalArgumentException("La extensión debe ser mayor que 0");
        }
        this.extension = extension;
    }

    /**
     * Establece el número de habitantes de la localidad.
     * 
     * @param habitantes Número de habitantes.
     * @throws IllegalArgumentException Si el número de habitantes es negativo.
     */
    public void setHabitantes(int habitantes) {
        if (habitantes < 0) {
            throw new IllegalArgumentException("El número de habitantes no puede ser negativo");
        }
        this.habitantes = habitantes;
    }

    /**
     * Obtiene la extensión de la localidad.
     * 
     * @return La extensión en km².
     */
    public double getExtension() {
        return extension;
    }

    /**
     * Obtiene el número de habitantes de la localidad.
     * 
     * @return El número de habitantes.
     */
    public int getHabitantes() {
        return habitantes;
    }

    /**
     * Calcula la densidad de población de la localidad.
     * 
     * @return La densidad de población en habitantes por km².
     */
    public double calcularDensidadPoblacion() {
        return habitantes / extension;
    }

    @Override
    public void visualizar() {
        super.visualizar();
        System.out.println("Tipo: Localidad");
        System.out.println("Extensión: " + extension + " km²");
        System.out.println("Habitantes: " + habitantes);
        System.out.println("Densidad de población: " + calcularDensidadPoblacion() + " hab/km²");
        System.out.println("----------------------------------------");
    }
}