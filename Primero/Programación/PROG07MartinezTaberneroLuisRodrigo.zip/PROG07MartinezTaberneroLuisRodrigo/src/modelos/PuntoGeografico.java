package modelos;

import interfaces.IPuntoGeografico;

/**
 * Clase que representa un punto geográfico con longitud, latitud y altura.
 */
public class PuntoGeografico implements IPuntoGeografico {
    private double longitud; // Entre -180 y 180 grados
    private double latitud; // Entre -90 y 90 grados
    private double altura; // Mayor que 0

    private final static double RADIO_TIERRA = 6371; // Radio de la Tierra en kilómetros

    /**
     * Constructor para crear un punto geográfico.
     * 
     * @param longitud Longitud del punto geográfico.
     * @param latitud  Latitud del punto geográfico.
     * @param altura   Altura del punto geográfico.
     * @throws IllegalArgumentException Si los valores están fuera del rango
     *                                  permitido.
     */
    public PuntoGeografico(double longitud, double latitud, double altura) {
        setLongitud(longitud);
        setLatitud(latitud);
        setAltura(altura);
    }

    /**
     * Establece la longitud del punto geográfico.
     * 
     * @param longitud Longitud en grados (-180 a 180).
     * @throws IllegalArgumentException Si la longitud está fuera del rango
     *                                  permitido.
     */
    public void setLongitud(double longitud) {
        if (longitud < -180 || longitud > 180) {
            throw new IllegalArgumentException("La longitud debe estar entre -180 y 180 grados");
        }
        this.longitud = longitud;
    }

    /**
     * Establece la latitud del punto geográfico.
     * 
     * @param latitud Latitud en grados (-90 a 90).
     * @throws IllegalArgumentException Si la latitud está fuera del rango
     *                                  permitido.
     */
    public void setLatitud(double latitud) {
        if (latitud < -90 || latitud > 90) {
            throw new IllegalArgumentException("La latitud debe estar entre -90 y 90 grados");
        }
        this.latitud = latitud;
    }

    /**
     * Establece la altura del punto geográfico.
     * 
     * @param altura Altura en metros (mayor que 0).
     * @throws IllegalArgumentException Si la altura es negativa o cero.
     */
    public void setAltura(double altura) {
        if (altura <= 0) {
            throw new IllegalArgumentException("La altura debe ser mayor que 0");
        }
        this.altura = altura;
    }

    /**
     * Obtiene la longitud del punto geográfico.
     * 
     * @return La longitud en grados.
     */
    public double getLongitud() {
        return longitud;
    }

    /**
     * Obtiene la latitud del punto geográfico.
     * 
     * @return La latitud en grados.
     */
    public double getLatitud() {
        return latitud;
    }

    /**
     * Obtiene la altura del punto geográfico.
     * 
     * @return La altura en metros.
     */
    public double getAltura() {
        return altura;
    }

    /**
     * Convierte grados a radianes.
     * 
     * @param grados Ángulo en grados.
     * @return Ángulo en radianes.
     */
    private double gradosARadianes(double grados) {
        return grados * Math.PI / 180;
    }

    @Override
    public double calcularDistancia(IPuntoGeografico otro) {
        if (!(otro instanceof PuntoGeografico)) {
            throw new IllegalArgumentException("El parámetro debe ser de tipo PuntoGeografico");
        }

        PuntoGeografico puntoOtro = (PuntoGeografico) otro;

        // Convertir latitudes y longitudes a radianes
        double lat1 = gradosARadianes(this.latitud);
        double lat2 = gradosARadianes(puntoOtro.getLatitud());
        double long1 = gradosARadianes(this.longitud);
        double long2 = gradosARadianes(puntoOtro.getLongitud());

        // Diferencias de latitud y longitud
        double deltaLat = lat2 - lat1;
        double deltaLong = long2 - long1;

        // Fórmula de Haversine
        double a = Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
                Math.cos(lat1) * Math.cos(lat2) *
                        Math.sin(deltaLong / 2) * Math.sin(deltaLong / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distancia = RADIO_TIERRA * c;

        return distancia;
    }

    @Override
    public void visualizar() {
        System.out.println("Punto Geográfico:");
        System.out.println("  Longitud: " + longitud + "°");
        System.out.println("  Latitud: " + latitud + "°");
        System.out.println("  Altura: " + altura + " metros");
    }
}