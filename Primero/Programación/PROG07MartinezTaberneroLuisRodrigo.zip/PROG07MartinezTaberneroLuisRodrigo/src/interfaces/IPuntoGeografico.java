package interfaces;

/**
 * Interfaz que define las operaciones básicas de un punto geográfico.
 */
public interface IPuntoGeografico {
    /**
     * Calcula la distancia entre dos puntos geográficos utilizando la fórmula de
     * Haversine.
     * 
     * @param otro El otro punto geográfico con el que calcular la distancia.
     * @return La distancia en kilómetros entre los dos puntos.
     */
    double calcularDistancia(IPuntoGeografico otro);

    /**
     * Visualiza los datos del punto geográfico.
     */
    void visualizar();
}