/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog04luisrodrigomartineztabernero;

import java.util.Scanner;

/**
 *
 * @author bobovino
 */
public class PROG04LuisRodrigoMartinezTabernero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Creamos un objeto Scanner previo import para leer de la entrada estándar.
        Scanner scanner = new Scanner(System.in);

        try {
            // Pedimos los datos necesarios para hacer el cuadro/cuota
            // Encerramos en un try catch para validar los datos.
            System.out.print("Introduce el capital prestado: ");
            double capital = scanner.nextDouble();

            System.out.print("Introduce el interés anual (%): ");
            double interesAnual = scanner.nextDouble();

            System.out.print("Introduce el número de cuotas: ");
            int numeroCuotas = scanner.nextInt();

            // Creamos nuevo objeto para construir un nuevo cuadro.
            AmortizacionFrances amortizacion = new AmortizacionFrances(capital, interesAnual, numeroCuotas);

            // Llamamos a los dos métodos de la otra clase
            double cuotaMensual = amortizacion.calcularCuotaMensual();
            System.out.printf("La cuota mensual es: %.2f\n", cuotaMensual);

            amortizacion.mostrarCuadroAmortizacion();
        } catch (IllegalArgumentException e) {
            // Pillamos las posibles excepciones creadas en el constructor
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            // Por si hay otro tipo de excepciones
            System.out.println("Error: Entrada no válida.");
        } finally {
            // Nos aseguramos de que pase lo que pase siempre cerremos el scanner
            scanner.close();
        }
    }
}
