/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog04luisrodrigomartineztabernero;

/**
 *
 * @author bobovino
 */

public class AmortizacionFrances {
    private double capital;
    private double interesAnual;
    private int numeroCuotas;

    // Constructor que recibe el capital prestado, el interés anual y el número de
    // cuotas.
    public AmortizacionFrances(double capital, double interesAnual, int numeroCuotas) {
        // Si el capital es negativo, lanzamos una excepción.
        if (capital <= 0) {
            throw new IllegalArgumentException("El capital prestado debe ser mayor que cero.");
        }
        // Si el interés anual no está entre 1 y 50, lanzamos una excepción con mensaje.
        if (interesAnual < 1 || interesAnual > 50) {
            throw new IllegalArgumentException("El interés anual debe estar entre 1% y 50%.");
        }
        // Si el número de cuotas no está entre 6 y 360, lanzamos una excepción.
        if (numeroCuotas < 6 || numeroCuotas > 360) {
            throw new IllegalArgumentException("El número de cuotas debe estar entre 6 y 360 meses.");
        }
        this.capital = capital;
        this.interesAnual = interesAnual;
        this.numeroCuotas = numeroCuotas;
    }

    // Método para calcular la cuota mensual usando la fórmula del sistema de
    // amortización francés
    public double calcularCuotaMensual() {
        double interesMensual = (interesAnual / 100) / 12;
        // Retornamos la fórmula esta tan bonita que aparece en la guía de la tarea
        return (capital * interesMensual) / (1 - Math.pow(1 + interesMensual, -numeroCuotas));
    }

    // Método para mostrar el cuadro de amortización
    public void mostrarCuadroAmortizacion() {
        double cuotaMensual = calcularCuotaMensual();
        double capitalPendiente = capital;
        double interesMensual = (interesAnual / 100) / 12;

        // Header del cuadro y luego iteramos para calcular cada celda. La cuota mensual
        // es constante.
        System.out.printf("%-10s%-10s%-10s%-10s%-15s\n", "Mes", "Cuota", "Interés", "Capital", "Saldo Pendiente");

        // Iterar sobre cada mes para calcular y mostrar los detalles de la cuota
        for (int mes = 1; mes <= numeroCuotas; mes++) {
            double interes = capitalPendiente * interesMensual;// Interés del mes actual
            double capitalAmortizado = cuotaMensual - interes;
            capitalPendiente -= capitalAmortizado;// Actualizamos el capital

            // Imprimir los detalles del mes actual.
            System.out.printf("%-10d%-10.2f%-10.2f%-10.2f%-15.2f\n", mes, cuotaMensual, interes, capitalAmortizado,
                    capitalPendiente);
        }
    }
}
