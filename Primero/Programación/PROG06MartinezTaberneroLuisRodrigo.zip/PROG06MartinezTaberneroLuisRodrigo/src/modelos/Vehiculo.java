package modelos;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;

/**
 * Clase que representa un vehículo en el concesionario.
 */
public class Vehiculo {
    private String marca;
    private String matricula;
    private int kilometros;
    private LocalDate fechaMatriculacion;
    private String descripcion;
    private double precio;
    
    // Patrones para validación
    private static final Pattern PATRON_MATRICULA = Pattern.compile("\\d{4}[A-Z]{3}");
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
    /**
     * Constructor de la clase Vehiculo.
     * 
     * @param marca Marca del vehículo
     * @param matricula Matrícula del vehículo (formato NNNNLLL)
     * @param kilometros Kilómetros del vehículo
     * @param fechaMatriculacion Fecha de matriculación (formato dd/mm/aaaa)
     * @param descripcion Descripción del vehículo
     * @param precio Precio del vehículo
     * @throws IllegalArgumentException Si algún parámetro no cumple las validaciones
     */
    public Vehiculo(String marca, String matricula, int kilometros, String fechaMatriculacion, 
                   String descripcion, double precio) throws IllegalArgumentException {
        setMarca(marca);
        setMatricula(matricula);
        setKilometros(kilometros);
        setFechaMatriculacion(fechaMatriculacion);
        setDescripcion(descripcion);
        setPrecio(precio);
    }
    
    /**
     * Establece la marca del vehículo.
     * 
     * @param marca Marca del vehículo
     * @throws IllegalArgumentException Si la marca está vacía
     */
    public void setMarca(String marca) throws IllegalArgumentException {
        if (marca == null || marca.trim().isEmpty()) {
            throw new IllegalArgumentException("La marca no puede estar vacía");
        }
        this.marca = marca;
    }
    
    /**
     * Establece la matrícula del vehículo.
     * 
     * @param matricula Matrícula del vehículo (formato NNNNLLL)
     * @throws IllegalArgumentException Si la matrícula no tiene el formato correcto
     */
    public void setMatricula(String matricula) throws IllegalArgumentException {
        if (matricula == null || !PATRON_MATRICULA.matcher(matricula).matches()) {
            throw new IllegalArgumentException("La matrícula debe tener el formato NNNNLLL");
        }
        this.matricula = matricula;
    }
    
    /**
     * Establece los kilómetros del vehículo.
     * 
     * @param kilometros Kilómetros del vehículo
     * @throws IllegalArgumentException Si los kilómetros son negativos
     */
    public void setKilometros(int kilometros) throws IllegalArgumentException {
        if (kilometros < 0) {
            throw new IllegalArgumentException("Los kilómetros no pueden ser negativos");
        }
        this.kilometros = kilometros;
    }
    
    /**
     * Establece la fecha de matriculación del vehículo.
     * 
     * @param fechaMatriculacion Fecha de matriculación (formato dd/mm/aaaa)
     * @throws IllegalArgumentException Si la fecha no tiene el formato correcto
     */
    public void setFechaMatriculacion(String fechaMatriculacion) throws IllegalArgumentException {
        try {
            this.fechaMatriculacion = LocalDate.parse(fechaMatriculacion, FORMATO_FECHA);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("La fecha debe tener el formato dd/MM/yyyy y ser válida");
        }
    }
    
    /**
     * Establece la descripción del vehículo.
     * 
     * @param descripcion Descripción del vehículo
     * @throws IllegalArgumentException Si la descripción está vacía
     */
    public void setDescripcion(String descripcion) throws IllegalArgumentException {
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripción no puede estar vacía");
        }
        this.descripcion = descripcion;
    }
    
    /**
     * Establece el precio del vehículo.
     * 
     * @param precio Precio del vehículo
     * @throws IllegalArgumentException Si el precio no es mayor que cero
     */
    public void setPrecio(double precio) throws IllegalArgumentException {
        if (precio <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor que cero");
        }
        this.precio = precio;
    }
    
    /**
     * Obtiene la marca del vehículo.
     * 
     * @return Marca del vehículo
     */
    public String getMarca() {
        return marca;
    }
    
    /**
     * Obtiene la matrícula del vehículo.
     * 
     * @return Matrícula del vehículo
     */
    public String getMatricula() {
        return matricula;
    }
    
    /**
     * Obtiene los kilómetros del vehículo.
     * 
     * @return Kilómetros del vehículo
     */
    public int getKilometros() {
        return kilometros;
    }
    
    /**
     * Obtiene la fecha de matriculación del vehículo.
     * 
     * @return Fecha de matriculación
     */
    public LocalDate getFechaMatriculacion() {
        return fechaMatriculacion;
    }
    
    /**
     * Obtiene la fecha de matriculación del vehículo en formato String.
     * 
     * @return Fecha de matriculación formateada
     */
    public String getFechaMatriculacionFormateada() {
        return fechaMatriculacion.format(FORMATO_FECHA);
    }
    
    /**
     * Obtiene la descripción del vehículo.
     * 
     * @return Descripción del vehículo
     */
    public String getDescripcion() {
        return descripcion;
    }
    
    /**
     * Obtiene el precio del vehículo.
     * 
     * @return Precio del vehículo
     */
    public double getPrecio() {
        return precio;
    }
    
    /**
     * Calcula la antigüedad del vehículo en años.
     * 
     * @return Antigüedad del vehículo en años
     */
    public int getAntiguedad() {
        return Period.between(fechaMatriculacion, LocalDate.now()).getYears();
    }
    
    /**
     * Incrementa los kilómetros del vehículo.
     * 
     * @param kilometrosAdicionales Kilómetros a añadir
     * @throws IllegalArgumentException Si los kilómetros a añadir son negativos
     */
    public void incrementarKilometros(int kilometrosAdicionales) throws IllegalArgumentException {
        if (kilometrosAdicionales < 0) {
            throw new IllegalArgumentException("No se pueden añadir kilómetros negativos");
        }
        this.kilometros += kilometrosAdicionales;
    }
}