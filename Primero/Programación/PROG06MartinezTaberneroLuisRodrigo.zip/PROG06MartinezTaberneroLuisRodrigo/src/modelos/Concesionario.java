package modelos;

/**
 * Clase que representa un concesionario de vehículos.
 */
public class Concesionario {
    private Vehiculo[] vehiculos;
    private int numVehiculos;
    private static final int MAX_VEHICULOS = 50;
    
    /**
     * Constructor de la clase Concesionario.
     * Inicializa el array de vehículos con la capacidad máxima.
     */
    public Concesionario() {
        this.vehiculos = new Vehiculo[MAX_VEHICULOS];
        this.numVehiculos = 0;
    }
    
    /**
     * Establece el número de vehículos.
     * 
     * @param numVehiculos Número de vehículos
     * @throws IllegalArgumentException Si el número de vehículos es negativo o mayor que la capacidad máxima
     */
    public void setNumVehiculos(int numVehiculos) throws IllegalArgumentException {
        if (numVehiculos < 0) {
            throw new IllegalArgumentException("El número de vehículos no puede ser negativo");
        }
        if (numVehiculos > MAX_VEHICULOS) {
            throw new IllegalArgumentException("El número de vehículos no puede superar " + MAX_VEHICULOS);
        }
        this.numVehiculos = numVehiculos;
    }
    
    /**
     * Obtiene el número de vehículos del concesionario.
     * 
     * @return Número de vehículos
     */
    public int getNumVehiculos() {
        return numVehiculos;
    }
    
    /**
     * Obtiene el número máximo de vehículos que puede almacenar el concesionario.
     * 
     * @return Número máximo de vehículos
     */
    public int getMaxVehiculos() {
        return MAX_VEHICULOS;
    }
    
    /**
     * Añade un nuevo vehículo al concesionario.
     * 
     * @param vehiculo Vehículo a añadir
     * @throws IllegalArgumentException Si el concesionario está lleno o el vehículo ya existe
     */
    public void nuevoVehiculo(Vehiculo vehiculo) throws IllegalArgumentException {
        // Comprobar si el concesionario está lleno
        if (numVehiculos >= MAX_VEHICULOS) {
            throw new IllegalArgumentException("El concesionario está lleno");
        }
        
        // Comprobar si ya existe un vehículo con la misma matrícula
        if (buscarVehiculo(vehiculo.getMatricula()) != null) {
            throw new IllegalArgumentException("Ya existe un vehículo con esa matrícula");
        }
        
        // Añadir el vehículo al array
        vehiculos[numVehiculos] = vehiculo;
        numVehiculos++;
    }
    
    /**
     * Busca un vehículo por matrícula.
     * 
     * @param matricula Matrícula del vehículo a buscar
     * @return El vehículo encontrado o null si no existe
     */
    public Vehiculo buscarVehiculo(String matricula) {
        for (int i = 0; i < numVehiculos; i++) {
            if (vehiculos[i].getMatricula().equals(matricula)) {
                return vehiculos[i];
            }
        }
        return null;
    }
    
    /**
     * Obtiene todos los vehículos del concesionario.
     * 
     * @return Array con los vehículos del concesionario
     */
    public Vehiculo[] getVehiculos() {
        Vehiculo[] resultado = new Vehiculo[numVehiculos];
        System.arraycopy(vehiculos, 0, resultado, 0, numVehiculos);
        return resultado;
    }
    
    /**
     * Modifica los kilómetros de un vehículo.
     * 
     * @param matricula Matrícula del vehículo
     * @param kilometrosAdicionales Kilómetros a añadir
     * @throws IllegalArgumentException Si el vehículo no existe o los kilómetros son negativos
     */
    public void modificarKilometros(String matricula, int kilometrosAdicionales) throws IllegalArgumentException {
        Vehiculo vehiculo = buscarVehiculo(matricula);
        if (vehiculo == null) {
            throw new IllegalArgumentException("No existe un vehículo con matrícula " + matricula);
        }
        vehiculo.incrementarKilometros(kilometrosAdicionales);
    }
}