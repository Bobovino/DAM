package progo6martineztaberneroluisrodrigo;

import java.text.DecimalFormat;
import java.util.Scanner;
import modelos.Concesionario;
import modelos.Vehiculo;

/**
 * Clase principal que gestiona el concesionario de vehículos.
 */
public class PROGO6MartinezTaberneroLuisRodrigo {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Concesionario concesionario = new Concesionario();
    private static final DecimalFormat formatoPrecio = new DecimalFormat("#,##0.00 €");

    public static void main(String[] args) {
        int opcion;

        do {
            mostrarMenu();
            opcion = leerOpcion();

            switch (opcion) {
                case 1:
                    nuevoVehiculo();
                    break;
                case 2:
                    listarVehiculos();
                    break;
                case 3:
                    buscarVehiculo();
                    break;
                case 4:
                    modificarKilometros();
                    break;
                case 5:
                    System.out.println("Saliendo de la aplicación...");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }

            if (opcion != 5) {
                System.out.println("\nPulse ENTER para continuar...");
                scanner.nextLine();
            }
        } while (opcion != 5);
    }

    /**
     * Muestra el menú principal de la aplicación.
     */
    private static void mostrarMenu() {
        System.out.println("\n========================================");
        System.out.println("GESTIÓN DE VEHÍCULOS DE UN CONCESIONARIO");
        System.out.println("========================================");
        System.out.println("1. Nuevo Vehículo");
        System.out.println("2. Listar Vehículos");
        System.out.println("3. Buscar Vehículo");
        System.out.println("4. Modificar Kilómetros de Vehículo");
        System.out.println("5. Salir");
        System.out.println("----------------------------------------");
    }

    /**
     * Lee una opción del menú.
     * 
     * @return Opción seleccionada
     */
    private static int leerOpcion() {
        int opcion = 0;
        boolean valido = false;

        do {
            try {
                System.out.print("Elige una opción: ");
                opcion = Integer.parseInt(scanner.nextLine());
                valido = true;
            } catch (NumberFormatException e) {
                System.out.println("Error: Debe introducir un número.");
            }
        } while (!valido);

        return opcion;
    }

    /**
     * Solicita los datos de un nuevo vehículo y lo añade al concesionario.
     */
    private static void nuevoVehiculo() {
        System.out.println("\n--- AÑADIR NUEVO VEHÍCULO ---");

        try {
            System.out.print("Marca: ");
            String marca = scanner.nextLine();

            System.out.print("Matrícula (formato NNNNLLL): ");
            String matricula = scanner.nextLine();

            int kilometros = leerEnteroPositivo("Kilómetros: ");

            System.out.print("Fecha de matriculación (dd/MM/yyyy): ");
            String fechaMatriculacion = scanner.nextLine();

            System.out.print("Descripción: ");
            String descripcion = scanner.nextLine();

            double precio = leerDecimalPositivo("Precio: ");

            Vehiculo vehiculo = new Vehiculo(marca, matricula, kilometros, fechaMatriculacion, descripcion, precio);
            concesionario.nuevoVehiculo(vehiculo);

            System.out.println("Vehículo añadido correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    /**
     * Lista todos los vehículos del concesionario.
     */
    private static void listarVehiculos() {
        System.out.println("\n--- LISTADO DE VEHÍCULOS ---");

        Vehiculo[] vehiculos = concesionario.getVehiculos();

        if (vehiculos.length == 0) {
            System.out.println("No hay vehículos en el concesionario.");
            return;
        }

        for (Vehiculo vehiculo : vehiculos) {
            System.out.println("Marca: " + vehiculo.getMarca());
            System.out.println("Matrícula: " + vehiculo.getMatricula());
            System.out.println("Precio: " + formatoPrecio.format(vehiculo.getPrecio()));
            System.out.println("Kilómetros: " + vehiculo.getKilometros());
            System.out.println("Fecha de matriculación: " + vehiculo.getFechaMatriculacionFormateada());
            System.out.println("Años: " + vehiculo.getAntiguedad());
            System.out.println("Descripción: " + vehiculo.getDescripcion());
            System.out.println("----------------------------------");
        }
    }

    /**
     * Busca un vehículo por matrícula.
     */
    private static void buscarVehiculo() {
        System.out.println("\n--- BUSCAR VEHÍCULO ---");

        System.out.print("Introduzca la matrícula: ");
        String matricula = scanner.nextLine();

        Vehiculo vehiculo = concesionario.buscarVehiculo(matricula);

        if (vehiculo != null) {
            System.out.println("Vehículo encontrado:");
            System.out.println("Marca: " + vehiculo.getMarca());
            System.out.println("Matrícula: " + vehiculo.getMatricula());
            System.out.println("Años: " + vehiculo.getAntiguedad());
            System.out.println("Precio: " + formatoPrecio.format(vehiculo.getPrecio()));
        } else {
            System.out.println("No se ha encontrado ningún vehículo con matrícula " + matricula);
        }
    }

    /**
     * Modifica los kilómetros de un vehículo.
     */
    private static void modificarKilometros() {
        System.out.println("\n--- MODIFICAR KILÓMETROS ---");

        System.out.print("Introduzca la matrícula: ");
        String matricula = scanner.nextLine();

        try {
            int kilometrosAdicionales = leerEnteroPositivo("Kilómetros a añadir: ");
            concesionario.modificarKilometros(matricula, kilometrosAdicionales);
            System.out.println("Kilómetros actualizados correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    /**
     * Lee un número entero positivo.
     * 
     * @param mensaje Mensaje a mostrar
     * @return Número entero positivo
     */
    private static int leerEnteroPositivo(String mensaje) {
        int valor = 0;
        boolean valido = false;

        do {
            try {
                System.out.print(mensaje);
                valor = Integer.parseInt(scanner.nextLine());
                if (valor < 0) {
                    System.out.println("El valor debe ser mayor o igual a 0.");
                } else {
                    valido = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Debe introducir un número entero.");
            }
        } while (!valido);

        return valor;
    }

    /**
     * Lee un número decimal positivo.
     * 
     * @param mensaje Mensaje a mostrar
     * @return Número decimal positivo
     */
    private static double leerDecimalPositivo(String mensaje) {
        double valor = 0;
        boolean valido = false;

        do {
            try {
                System.out.print(mensaje);
                valor = Double.parseDouble(scanner.nextLine());
                if (valor <= 0) {
                    System.out.println("El valor debe ser mayor que 0.");
                } else {
                    valido = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Debe introducir un número decimal.");
            }
        } while (!valido);

        return valor;
    }
}