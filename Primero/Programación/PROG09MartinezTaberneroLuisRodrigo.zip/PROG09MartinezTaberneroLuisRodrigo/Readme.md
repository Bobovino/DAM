# Para generar docs

javadoc -d docs -sourcepath src -subpackages prog09martineztaberneroluisrodrigo

# Para abrir los docs generados

xdg-open docs/index.html
