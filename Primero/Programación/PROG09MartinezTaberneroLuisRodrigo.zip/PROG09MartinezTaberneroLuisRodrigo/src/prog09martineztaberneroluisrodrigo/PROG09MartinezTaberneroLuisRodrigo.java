package prog09martineztaberneroluisrodrigo;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import modelos.Localidad;
import modelos.Lugar;
import modelos.PDI;
import modelos.PuntoGeografico;
import modelos.Lugar.TipoLugar;

/**
 * PROG09 - Sistema de Información Geográfica (SIG) con persistencia de datos.
 *
 * Se utiliza un único fichero binario (pdiData.bin) para almacenar todos los
 * PDIs ya que, al ser ambos tipos de PDI (Localidad y Lugar) subclases de la
 * clase PDI, pueden tratarse de forma polimórfica.
 * 
 * Además, se añade la opción "Listado PDI" para generar un fichero de texto con
 * la información básica de cada PDI.
 *
 * @author Rodrigo Martínez Tabernero
 */

/**
 * Clase principal del SIG que gestiona la interacción con el usuario.
 */
public class PROG09MartinezTaberneroLuisRodrigo {

    // Estructuras dinámicas para almacenar los PDIs.
    private static ArrayList<Localidad> localidades = new ArrayList<>();
    private static ArrayList<Lugar> lugares = new ArrayList<>();

    // Nombre del fichero binario para persistencia.
    private static final String DATA_FILE = "pdiData.bin";

    // Scanner para entrada de datos.
    private static Scanner scanner = new Scanner(System.in);

    /**
     * Constructor por defecto de PROG09MartinezTaberneroLuisRodrigo.
     * Esta clase no debe instanciarse, pues sus métodos son estáticos.
     * He puesto esto para quitar un warning de javadoc, simplemente.
     */
    private PROG09MartinezTaberneroLuisRodrigo() {
        // Evita la instanciación
    }

    /**
     * Punto de entrada de la aplicación.
     * 
     * @param args Argumentos de línea de comandos.
     */
    public static void main(String[] args) {
        // Al iniciar, carga los datos existentes (si los hay).
        cargarDatos();

        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            try {
                switch (opcion) {
                    case 1:
                        crearLocalidad();
                        break;
                    case 2:
                        crearLugar();
                        break;
                    case 3:
                        visualizarLocalidades();
                        break;
                    case 4:
                        visualizarLugares();
                        break;
                    case 5:
                        eliminarLocalidad();
                        break;
                    case 6:
                        eliminarLugar();
                        break;
                    case 7:
                        calcularDistanciaEntrePDIs();
                        break;
                    case 8:
                        generarListadoPDI();
                        break;
                    case 0:
                        // Al salir, guarda los PDIs en el fichero binario.
                        guardarDatos();
                        System.out.println("Saliendo del programa...");
                        break;
                    default:
                        System.out.println("Opción no válida. Intente de nuevo.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (opcion != 0);
        scanner.close();
    }

    private static void mostrarMenu() {
        System.out.println("\n===== MENÚ SIG =====");
        System.out.println("1. Crear Localidad");
        System.out.println("2. Crear Lugar");
        System.out.println("3. Mostrar Localidades");
        System.out.println("4. Mostrar Lugares");
        System.out.println("5. Eliminar Localidad");
        System.out.println("6. Eliminar Lugar");
        System.out.println("7. Calcular distancia entre dos PDIs");
        System.out.println("8. Listado PDI (generar fichero de texto .txt)");
        System.out.println("0. Guardar (En binario) y salir");
    }

    private static void crearLocalidad() {
        System.out.println("\n--- Crear Localidad ---");
        String nombre = leerString("Nombre: ");
        PuntoGeografico punto = crearPuntoGeografico();
        double valoracion = leerDouble("Valoración (0 a 5): ");
        double extension = leerDouble("Extensión (km²): ");
        int habitantes = leerEntero("Número de habitantes: ");
        try {
            Localidad loc = new Localidad(nombre, punto, valoracion, extension, habitantes);
            localidades.add(loc);
            System.out.println("Localidad creada correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error al crear la localidad: " + e.getMessage());
        }
    }

    private static void crearLugar() {
        System.out.println("\n--- Crear Lugar ---");
        String nombre = leerString("Nombre: ");
        PuntoGeografico punto = crearPuntoGeografico();
        double valoracion = leerDouble("Valoración (0 a 5): ");
        String descripcion = leerString("Descripción: ");
        TipoLugar tipo = seleccionarTipoLugar();
        try {
            Lugar lugar = new Lugar(nombre, punto, valoracion, descripcion, tipo);
            lugares.add(lugar);
            System.out.println("Lugar creado correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error al crear el lugar: " + e.getMessage());
        }
    }

    private static PuntoGeografico crearPuntoGeografico() {
        System.out.println("\n--- Crear Punto Geográfico ---");
        double longitud = 0, latitud = 0, altura = 0;
        boolean valido = false;
        while (!valido) {
            try {
                longitud = leerDouble("Longitud (-180 a 180): ");
                if (longitud < -180 || longitud > 180)
                    throw new IllegalArgumentException("Longitud fuera de rango");
                valido = true;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        valido = false;
        while (!valido) {
            try {
                latitud = leerDouble("Latitud (-90 a 90): ");
                if (latitud < -90 || latitud > 90)
                    throw new IllegalArgumentException("Latitud fuera de rango");
                valido = true;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        valido = false;
        while (!valido) {
            try {
                altura = leerDouble("Altura (mayor que 0): ");
                if (altura <= 0)
                    throw new IllegalArgumentException("La altura debe ser mayor que 0");
                valido = true;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        return new PuntoGeografico(longitud, latitud, altura);
    }

    private static TipoLugar seleccionarTipoLugar() {
        System.out.println("Tipos de Lugar:");
        System.out.println("1. RESTAURANTE");
        System.out.println("2. CAFETERIA");
        System.out.println("3. HOTEL");
        System.out.println("4. MONUMENTO");
        System.out.println("5. MUSEO");
        int op;
        do {
            op = leerEntero("Seleccione un tipo (1-5): ");
        } while (op < 1 || op > 5);
        switch (op) {
            case 1:
                return TipoLugar.RESTAURANTE;
            case 2:
                return TipoLugar.CAFETERIA;
            case 3:
                return TipoLugar.HOTEL;
            case 4:
                return TipoLugar.MONUMENTO;
            case 5:
                return TipoLugar.MUSEO;
            default:
                return TipoLugar.RESTAURANTE;
        }
    }

    private static void visualizarLocalidades() {
        System.out.println("\n--- Localidades Registradas ---");
        if (localidades.isEmpty()) {
            System.out.println("No hay localidades registradas.");
            return;
        }
        for (int i = 0; i < localidades.size(); i++) {
            System.out.println("Localidad #" + (i + 1));
            localidades.get(i).visualizar();
        }
    }

    private static void visualizarLugares() {
        System.out.println("\n--- Lugares Registrados ---");
        if (lugares.isEmpty()) {
            System.out.println("No hay lugares registrados.");
            return;
        }
        for (int i = 0; i < lugares.size(); i++) {
            System.out.println("Lugar #" + (i + 1));
            lugares.get(i).visualizar();
        }
    }

    private static void eliminarLocalidad() {
        if (localidades.isEmpty()) {
            System.out.println("No existen localidades a eliminar.");
            return;
        }
        System.out.println("\n--- Eliminar Localidad ---");
        for (int i = 0; i < localidades.size(); i++) {
            System.out.println((i + 1) + ". " + localidades.get(i).getNombre());
        }
        int indice = leerEntero("Seleccione el número de la localidad a eliminar: ");
        if (indice < 1 || indice > localidades.size()) {
            System.out.println("Índice no válido");
            return;
        }
        localidades.remove(indice - 1);
        System.out.println("Localidad eliminada.");
    }

    private static void eliminarLugar() {
        if (lugares.isEmpty()) {
            System.out.println("No existen lugares a eliminar.");
            return;
        }
        System.out.println("\n--- Eliminar Lugar ---");
        for (int i = 0; i < lugares.size(); i++) {
            System.out.println((i + 1) + ". " + lugares.get(i).getNombre());
        }
        int indice = leerEntero("Seleccione el número del lugar a eliminar: ");
        if (indice < 1 || indice > lugares.size()) {
            System.out.println("Índice no válido");
            return;
        }
        lugares.remove(indice - 1);
        System.out.println("Lugar eliminado.");
    }

    private static void calcularDistanciaEntrePDIs() {
        ArrayList<PDI> pdIs = new ArrayList<>();
        pdIs.addAll(localidades);
        pdIs.addAll(lugares);

        if (pdIs.size() < 2) {
            System.out.println("No hay suficientes PDIs para calcular la distancia.");
            return;
        }

        System.out.println("\n--- Calcular Distancia Entre PDIs ---");
        for (int i = 0; i < pdIs.size(); i++) {
            System.out.println((i + 1) + ". " + pdIs.get(i).getNombre());
        }

        int idx1 = leerEntero("Seleccione el primer PDI: ");
        int idx2 = leerEntero("Seleccione el segundo PDI: ");
        if (idx1 < 1 || idx1 > pdIs.size() || idx2 < 1 || idx2 > pdIs.size()) {
            System.out.println("Índices no válidos.");
            return;
        }

        double distancia = pdIs.get(idx1 - 1).calcularDistancia(pdIs.get(idx2 - 1));
        System.out.println("La distancia entre \"" + pdIs.get(idx1 - 1).getNombre() + "\" y \"" +
                pdIs.get(idx2 - 1).getNombre() + "\" es: " + distancia + " km.");
    }

    // Generar un fichero de texto con un listado de todos los PDIs.
    private static void generarListadoPDI() {
        ArrayList<PDI> pdIs = new ArrayList<>();
        pdIs.addAll(localidades);
        pdIs.addAll(lugares);

        if (pdIs.isEmpty()) {
            System.out.println("No hay PDIs para listar.");
            return;
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("ListadoPDI.txt"))) {
            for (PDI pdi : pdIs) {
                writer.println("Nombre: " + pdi.getNombre() + " | Localización: "
                        + pdi.getLocalizacion().toString() + " | Valoración: " + pdi.getValoracion());
            }
            System.out.println("ListadoPDI.txt generado correctamente.");
        } catch (IOException e) {
            System.out.println("Error al generar el listado: " + e.getMessage());
        }
    }

    // Guarda todos los PDIs en un fichero binario.
    private static void guardarDatos() {
        ArrayList<PDI> PDIs = new ArrayList<>();
        PDIs.addAll(localidades);
        PDIs.addAll(lugares);

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(PDIs);
            System.out.println("Datos guardados en " + DATA_FILE);
        } catch (IOException e) {
            System.out.println("Error guardando los datos: " + e.getMessage());
        }
    }

    // Carga los PDIs desde el fichero binario (si existe) y los separa en las
    // listas correspondientes.
    private static void cargarDatos() {
        File file = new File(DATA_FILE);
        if (!file.exists()) {
            return;
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            Object obj = ois.readObject();
            if (obj instanceof ArrayList) {
                ArrayList<?> lista = (ArrayList<?>) obj;
                localidades.clear();
                lugares.clear();
                for (Object o : lista) {
                    if (o instanceof Localidad) {
                        localidades.add((Localidad) o);
                    } else if (o instanceof Lugar) {
                        lugares.add((Lugar) o);
                    }
                }
                System.out.println("Datos cargados correctamente desde " + DATA_FILE);
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error cargando los datos: " + e.getMessage());
        }
    }

    // Métodos de ayuda para la lectura de datos.
    private static int leerEntero(String mensaje) {
        System.out.print(mensaje);
        while (!scanner.hasNextInt()) {
            scanner.next();
            System.out.print("Entrada inválida. " + mensaje);
        }
        return scanner.nextInt();
    }

    private static double leerDouble(String mensaje) {
        System.out.print(mensaje);
        while (!scanner.hasNextDouble()) {
            scanner.next();
            System.out.print("Entrada inválida. " + mensaje);
        }
        return scanner.nextDouble();
    }

    private static String leerString(String mensaje) {
        System.out.print(mensaje);
        return scanner.next();
    }
}