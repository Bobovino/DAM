package modelos;

import java.io.Serializable;

/**
 * Clase base que representa un Punto de Interés (PDI). Auna las coordenadas
 * de un punto geográfico con información adicional (nombre y valoración).
 */

public abstract class PDI implements Serializable {
    // Google dice que con esta línea hacemos a la clase
    // compatible con diferentes versiones.
    private static final long serialVersionUID = 1L;

    private String nombre;
    private PuntoGeografico localizacion;
    private double valoracion; // Entre 0 y 5

    /**
     * Constructor para crear un PDI.
     * 
     * @param nombre       Nombre del PDI.
     * @param localizacion Punto geográfico donde se encuentra el PDI.
     * @param valoracion   Valoración del PDI (de 0 a 5).
     * @throws IllegalArgumentException Si los valores no son válidos.
     */
    public PDI(String nombre, PuntoGeografico localizacion, double valoracion) {
        setNombre(nombre);
        setLocalizacion(localizacion);
        setValoracion(valoracion);
    }

    /**
     * Establece el nombre del PDI.
     * 
     * @param nombre Nombre del PDI.
     * @throws IllegalArgumentException Si el nombre está vacío o es nulo.
     */
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío");
        }
        this.nombre = nombre;
    }

    /**
     * Establece la localización del PDI.
     * 
     * @param localizacion Punto geográfico donde se encuentra el PDI.
     * @throws IllegalArgumentException Si la localización es nula.
     */
    public void setLocalizacion(PuntoGeografico localizacion) {
        if (localizacion == null) {
            throw new IllegalArgumentException("La localización no puede ser nula");
        }
        this.localizacion = localizacion;
    }

    /**
     * Establece la valoración del PDI.
     * 
     * @param valoracion Valoración del PDI (de 0 a 5).
     * @throws IllegalArgumentException Si la valoración está fuera del rango
     *                                  permitido.
     */
    public void setValoracion(double valoracion) {
        if (valoracion < 0 || valoracion > 5) {
            throw new IllegalArgumentException("La valoración debe estar entre 0 y 5");
        }
        this.valoracion = valoracion;
    }

    /**
     * Obtiene el nombre del PDI.
     * 
     * @return El nombre del PDI.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene la localización del PDI.
     * 
     * @return El punto geográfico donde se encuentra el PDI.
     */
    public PuntoGeografico getLocalizacion() {
        return localizacion;
    }

    /**
     * Obtiene la valoración del PDI.
     * 
     * @return La valoración del PDI.
     */
    public double getValoracion() {
        return valoracion;
    }

    /**
     * Visualiza los datos generales del PDI.
     */
    public void visualizar() {
        System.out.println("Punto de Interés: " + nombre);
        System.out.println("Valoración: " + valoracion + "/5");
        System.out.println("Localización:");
        localizacion.visualizar();
    }

    /**
     * Calcula la distancia entre este PDI y otro.
     * 
     * @param otro El otro PDI con el que calcular la distancia.
     * @return La distancia en kilómetros entre los dos PDI.
     */
    public double calcularDistancia(PDI otro) {
        return this.localizacion.calcularDistancia(otro.getLocalizacion());
    }
}